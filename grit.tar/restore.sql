--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 9.5.4
-- Dumped by pg_dump version 9.5.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.validable_template DROP CONSTRAINT validable_templ_validable_id_7207bde9_fk_validable_validable_id;
ALTER TABLE ONLY public.usr_empresa DROP CONSTRAINT usr_empresa_user_ptr_id_86799ee2_fk_auth_user_id;
ALTER TABLE ONLY public.usr_empresa DROP CONSTRAINT usr_empresa__empresa_id_0a9c712d_fk_empresa_empresa_id;
ALTER TABLE ONLY public.usr_empleado DROP CONSTRAINT usr_empleado_user_ptr_id_1113d746_fk_auth_user_id;
ALTER TABLE ONLY public.usr_empleado DROP CONSTRAINT usr_empleado__empleado_id_64b11834_fk_empresa_empleado_id;
ALTER TABLE ONLY public.usr_auditor DROP CONSTRAINT usr_auditor_usuario_id_cc50615c_fk_auth_user_id;
ALTER TABLE ONLY public.usr_administrador DROP CONSTRAINT usr_administrador_usuario_id_78d32edb_fk_auth_user_id;
ALTER TABLE ONLY public.riesgo_riesgo DROP CONSTRAINT riesgo_riesgo_empresa_id_5dffbcdf_fk_empresa_empresa_id;
ALTER TABLE ONLY public.riesgo_riesgo_aproteger DROP CONSTRAINT riesgo_riesgo_aproteger_riesgo_id_5dd3585b_fk_riesgo_riesgo_id;
ALTER TABLE ONLY public.riesgo_evaluacionriesgos DROP CONSTRAINT riesgo_evaluacionriesgos_riesgo_id_f60b4173_fk_riesgo_riesgo_id;
ALTER TABLE ONLY public.riesgo_evaluacionempresa DROP CONSTRAINT riesgo_evaluacionempr_empresa_id_b50621e2_fk_empresa_empresa_id;
ALTER TABLE ONLY public.riesgo_evaluacionriesgos DROP CONSTRAINT riesgo_evalu_empresa_id_2f2d1fb6_fk_riesgo_evaluacionempresa_id;
ALTER TABLE ONLY public.riesgo_cargoriesgo DROP CONSTRAINT riesgo_cargoriesgo_cargo_id_6435fda8_fk_empresa_cargo_id;
ALTER TABLE ONLY public.riesgo_cargoriesgo DROP CONSTRAINT riesgo_cargories_criticidad_id_413d8e17_fk_riesgo_criticidad_id;
ALTER TABLE ONLY public.riesgo_cargoriesgo_aproteger DROP CONSTRAINT riesgo_cargori_cargoriesgo_id_2dc85ba9_fk_riesgo_cargoriesgo_id;
ALTER TABLE ONLY public.riesgo_cargoriesgo_aproteger DROP CONSTRAINT ries_elementoproteger_id_f8488bf1_fk_riesgo_elementoproteger_id;
ALTER TABLE ONLY public.riesgo_riesgo_aproteger DROP CONSTRAINT ries_elementoproteger_id_bf4062e6_fk_riesgo_elementoproteger_id;
ALTER TABLE ONLY public.norma_item DROP CONSTRAINT norma_item_norma_id_ed183017_fk_norma_norma_id;
ALTER TABLE ONLY public.norma_formato DROP CONSTRAINT norma_formato_item_id_6f3d34c4_fk_norma_item_id;
ALTER TABLE ONLY public.norma_formato DROP CONSTRAINT norm_formulario_digital_id_be65fd93_fk_formulario_formulario_id;
ALTER TABLE ONLY public.formulario_valor DROP CONSTRAINT formulario_valor_tipo_id_a2eccb49_fk_formulario_tipo_id;
ALTER TABLE ONLY public.formulario_revision DROP CONSTRAINT formulario_revis_registro_id_0883997d_fk_formulario_registro_id;
ALTER TABLE ONLY public.formulario_registro DROP CONSTRAINT formulario_regi_revisor_id_97ee2c76_fk_usr_empleado_user_ptr_id;
ALTER TABLE ONLY public.formulario_registro DROP CONSTRAINT formulario_reg_empleado_id_43cb4772_fk_usr_empleado_user_ptr_id;
ALTER TABLE ONLY public.formulario_registro DROP CONSTRAINT formulario_r_formulario_id_a70ee9cc_fk_formulario_formulario_id;
ALTER TABLE ONLY public.formulario_grupo DROP CONSTRAINT formulario_g_formulario_id_c633a729_fk_formulario_formulario_id;
ALTER TABLE ONLY public.formulario_entrada DROP CONSTRAINT formulario_entrada_valor_id_49a642ff_fk_formulario_valor_id;
ALTER TABLE ONLY public.formulario_entrada DROP CONSTRAINT formulario_entrada_campo_id_b6ca9d9a_fk_formulario_campo_id;
ALTER TABLE ONLY public.formulario_entrada DROP CONSTRAINT formulario_entra_registro_id_65067948_fk_formulario_registro_id;
ALTER TABLE ONLY public.formulario_campo DROP CONSTRAINT formulario_campo_tipo_id_7053693d_fk_formulario_tipo_id;
ALTER TABLE ONLY public.formulario_campo DROP CONSTRAINT formulario_campo_grupo_id_a0974800_fk_formulario_grupo_id;
ALTER TABLE ONLY public.formulario_registro DROP CONSTRAINT formulario__correccion_de_id_348a1bea_fk_formulario_revision_id;
ALTER TABLE ONLY public.epc_proyecto DROP CONSTRAINT epc_proyecto_grupo_id_80910624_fk_epc_grupo_id;
ALTER TABLE ONLY public.epc_progresografico DROP CONSTRAINT epc_progresografico_orden_id_0055a344_fk_epc_ordentrabajo_id;
ALTER TABLE ONLY public.epc_personal DROP CONSTRAINT epc_personal_empleado_id_44a99a67_fk_empresa_empleado_id;
ALTER TABLE ONLY public.epc_ordentrabajo DROP CONSTRAINT epc_ordentrabajo_revisor_id_aa2d418b_fk_epc_personal_id;
ALTER TABLE ONLY public.epc_ordentrabajo DROP CONSTRAINT epc_ordentrabajo_proyecto_id_806c76a7_fk_epc_proyecto_id;
ALTER TABLE ONLY public.epc_ordentrabajo DROP CONSTRAINT epc_ordentrabajo_personal_id_70bf2ec5_fk_epc_personal_id;
ALTER TABLE ONLY public.epc_ordentrabajo_dependencias DROP CONSTRAINT epc_ordentra_to_ordentrabajo_id_4e0f5e5c_fk_epc_ordentrabajo_id;
ALTER TABLE ONLY public.epc_ordentrabajo_dependencias DROP CONSTRAINT epc_ordent_from_ordentrabajo_id_923b73a2_fk_epc_ordentrabajo_id;
ALTER TABLE ONLY public.epc_invitacion DROP CONSTRAINT epc_invitacion_personal_id_0831a878_fk_epc_personal_id;
ALTER TABLE ONLY public.epc_invitacion DROP CONSTRAINT epc_invitacion_grupo_id_2e12aff9_fk_epc_grupo_id;
ALTER TABLE ONLY public.epc_gantt DROP CONSTRAINT epc_gantt_proyecto_id_5a532a4b_fk_epc_proyecto_id;
ALTER TABLE ONLY public.epc_adquisiscionmaterial DROP CONSTRAINT epc_adquisiscionmateria_material_id_e5aa9744_fk_epc_material_id;
ALTER TABLE ONLY public.epc_adquisiscionmaterial DROP CONSTRAINT epc_adquisiscionmateri_orden_id_cc504209_fk_epc_ordentrabajo_id;
ALTER TABLE ONLY public.epc_adquisiscionmaterial DROP CONSTRAINT epc_adquisiscionmat_tipo_id_78abdd9f_fk_epc_tipoadquisiscion_id;
ALTER TABLE ONLY public.epc_actividad DROP CONSTRAINT epc_actividad_registro_id_18505226_fk_formulario_registro_id;
ALTER TABLE ONLY public.epc_actividad DROP CONSTRAINT epc_actividad_orden_id_1e542c12_fk_epc_ordentrabajo_id;
ALTER TABLE ONLY public.epc_actividad DROP CONSTRAINT epc_actividad_formato_id_93cbb784_fk_formulario_formulario_id;
ALTER TABLE ONLY public.empresa_requisito DROP CONSTRAINT empresa_requisito_cargo_id_cbf75797_fk_empresa_cargo_id;
ALTER TABLE ONLY public.empresa_liquidacionnomina DROP CONSTRAINT empresa_liquidacion_empleado_id_16cecdb5_fk_empresa_empleado_id;
ALTER TABLE ONLY public.empresa_liquidacionnomina DROP CONSTRAINT empresa_liquidacion_contrato_id_fadf3c9d_fk_empresa_contrato_id;
ALTER TABLE ONLY public.empresa_jefes DROP CONSTRAINT empresa_jefes_empleado_id_afa73faa_fk_empresa_empleado_id;
ALTER TABLE ONLY public.empresa_jefes DROP CONSTRAINT empresa_jef_departamento_id_fcfffbe9_fk_empresa_departamento_id;
ALTER TABLE ONLY public.empresa_horasextra DROP CONSTRAINT empresa_horasextra_empleado_id_c9b697d1_fk_empresa_empleado_id;
ALTER TABLE ONLY public.empresa_horasextra DROP CONSTRAINT empresa_horasextra_contrato_id_3bb560f4_fk_empresa_contrato_id;
ALTER TABLE ONLY public.empresa_empresa DROP CONSTRAINT empresa_empresa_calculos_id_e73b5bbe_fk_empresa_calculos_id;
ALTER TABLE ONLY public.empresa_empleado DROP CONSTRAINT empresa_empleado_empresa_id_1fd4c0fa_fk_empresa_empresa_id;
ALTER TABLE ONLY public.empresa_empleado DROP CONSTRAINT empresa_empleado_cargo_id_94fcd079_fk_empresa_cargo_id;
ALTER TABLE ONLY public.empresa_empresa DROP CONSTRAINT empresa_e_configuracion_id_c0005a8b_fk_empresa_configuracion_id;
ALTER TABLE ONLY public.empresa_departamento DROP CONSTRAINT empresa_departamento_empresa_id_ccfc7787_fk_empresa_empresa_id;
ALTER TABLE ONLY public.empresa_departamento DROP CONSTRAINT empresa_departa_superior_id_5b87e15b_fk_empresa_departamento_id;
ALTER TABLE ONLY public.empresa_contrato DROP CONSTRAINT empresa_contrato_empleado_id_3ea030f1_fk_empresa_empleado_id;
ALTER TABLE ONLY public.empresa_contrato DROP CONSTRAINT empresa_contrato_cargo_id_f58ee511_fk_empresa_cargo_id;
ALTER TABLE ONLY public.empresa_cargo DROP CONSTRAINT empresa_car_departamento_id_e9dec7b4_fk_empresa_departamento_id;
ALTER TABLE ONLY public.empresa_asistencia DROP CONSTRAINT empresa_asistencia_empleado_id_7ef8bf26_fk_empresa_empleado_id;
ALTER TABLE ONLY public.empresa_asistencia DROP CONSTRAINT empresa_asistencia_contrato_id_93493407_fk_empresa_contrato_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id;
DROP INDEX public.usr_empresa_02cd0d7e;
DROP INDEX public.riesgo_riesgo_e8f8b1ef;
DROP INDEX public.riesgo_riesgo_aproteger_5c82ee88;
DROP INDEX public.riesgo_riesgo_aproteger_38b7f5b7;
DROP INDEX public.riesgo_evaluacionriesgos_e8f8b1ef;
DROP INDEX public.riesgo_evaluacionriesgos_5c82ee88;
DROP INDEX public.riesgo_evaluacionempresa_e8f8b1ef;
DROP INDEX public.riesgo_cargoriesgo_aproteger_e62b7a7b;
DROP INDEX public.riesgo_cargoriesgo_aproteger_38b7f5b7;
DROP INDEX public.riesgo_cargoriesgo_9c895cae;
DROP INDEX public.norma_item_85441dd2;
DROP INDEX public.norma_formato_82bfda79;
DROP INDEX public.formulario_valor_d3c0c18a;
DROP INDEX public.formulario_revision_69162670;
DROP INDEX public.formulario_registro_7485a580;
DROP INDEX public.formulario_registro_473dea9e;
DROP INDEX public.formulario_registro_3fe51010;
DROP INDEX public.formulario_grupo_3fe51010;
DROP INDEX public.formulario_entrada_e40f192a;
DROP INDEX public.formulario_entrada_69162670;
DROP INDEX public.formulario_entrada_0cdaf9cd;
DROP INDEX public.formulario_campo_d3c0c18a;
DROP INDEX public.formulario_campo_acaeb2d6;
DROP INDEX public.epc_proyecto_acaeb2d6;
DROP INDEX public.epc_personal_473dea9e;
DROP INDEX public.epc_ordentrabajo_f543c3f9;
DROP INDEX public.epc_ordentrabajo_dependencias_70fefa6c;
DROP INDEX public.epc_ordentrabajo_dependencias_559a1641;
DROP INDEX public.epc_ordentrabajo_beaf1098;
DROP INDEX public.epc_ordentrabajo_7485a580;
DROP INDEX public.epc_invitacion_acaeb2d6;
DROP INDEX public.epc_invitacion_4df638e8;
DROP INDEX public.epc_adquisiscionmaterial_eb4b9aaa;
DROP INDEX public.epc_adquisiscionmaterial_d3c0c18a;
DROP INDEX public.epc_adquisiscionmaterial_c33caba2;
DROP INDEX public.epc_actividad_poscicion_5721017e_uniq;
DROP INDEX public.epc_actividad_c33caba2;
DROP INDEX public.epc_actividad_7fa7f4f4;
DROP INDEX public.epc_actividad_69162670;
DROP INDEX public.empresa_liquidacionnomina_868819a8;
DROP INDEX public.empresa_liquidacionnomina_473dea9e;
DROP INDEX public.empresa_horasextra_868819a8;
DROP INDEX public.empresa_horasextra_473dea9e;
DROP INDEX public.empresa_empresa_59c4a75e;
DROP INDEX public.empresa_empleado_e8f8b1ef;
DROP INDEX public.empresa_empleado_d036ebc9;
DROP INDEX public.empresa_departamento_e8f8b1ef;
DROP INDEX public.empresa_departamento_bff560e2;
DROP INDEX public.empresa_contrato_d036ebc9;
DROP INDEX public.empresa_contrato_473dea9e;
DROP INDEX public.empresa_cargo_f5acfb16;
DROP INDEX public.empresa_asistencia_868819a8;
DROP INDEX public.empresa_asistencia_473dea9e;
DROP INDEX public.django_session_session_key_c0390e0f_like;
DROP INDEX public.django_session_de54fa62;
DROP INDEX public.django_admin_log_e8701ad4;
DROP INDEX public.django_admin_log_417f1b1c;
DROP INDEX public.auth_user_username_6821ab7c_like;
DROP INDEX public.auth_user_user_permissions_e8701ad4;
DROP INDEX public.auth_user_user_permissions_8373b171;
DROP INDEX public.auth_user_groups_e8701ad4;
DROP INDEX public.auth_user_groups_0e939a4f;
DROP INDEX public.auth_permission_417f1b1c;
DROP INDEX public.auth_group_permissions_8373b171;
DROP INDEX public.auth_group_permissions_0e939a4f;
DROP INDEX public.auth_group_name_a6ea08ec_like;
ALTER TABLE ONLY public.validable_validable DROP CONSTRAINT validable_validable_pkey;
ALTER TABLE ONLY public.validable_template DROP CONSTRAINT validable_template_validable_id_key;
ALTER TABLE ONLY public.validable_template DROP CONSTRAINT validable_template_pkey;
ALTER TABLE ONLY public.usr_empresa DROP CONSTRAINT usr_empresa_pkey;
ALTER TABLE ONLY public.usr_empleado DROP CONSTRAINT usr_empleado_pkey;
ALTER TABLE ONLY public.usr_empleado DROP CONSTRAINT usr_empleado__empleado_id_key;
ALTER TABLE ONLY public.usr_auditor DROP CONSTRAINT usr_auditor_usuario_id_key;
ALTER TABLE ONLY public.usr_auditor DROP CONSTRAINT usr_auditor_pkey;
ALTER TABLE ONLY public.usr_administrador DROP CONSTRAINT usr_administrador_usuario_id_key;
ALTER TABLE ONLY public.usr_administrador DROP CONSTRAINT usr_administrador_pkey;
ALTER TABLE ONLY public.riesgo_riesgo DROP CONSTRAINT riesgo_riesgo_pkey;
ALTER TABLE ONLY public.riesgo_riesgo_aproteger DROP CONSTRAINT riesgo_riesgo_aproteger_riesgo_id_1aaca1e0_uniq;
ALTER TABLE ONLY public.riesgo_riesgo_aproteger DROP CONSTRAINT riesgo_riesgo_aproteger_pkey;
ALTER TABLE ONLY public.riesgo_evaluacionriesgos DROP CONSTRAINT riesgo_evaluacionriesgos_pkey;
ALTER TABLE ONLY public.riesgo_evaluacionempresa DROP CONSTRAINT riesgo_evaluacionempresa_pkey;
ALTER TABLE ONLY public.riesgo_elementoproteger DROP CONSTRAINT riesgo_elementoproteger_pkey;
ALTER TABLE ONLY public.riesgo_criticidad DROP CONSTRAINT riesgo_criticidad_pkey;
ALTER TABLE ONLY public.riesgo_cargoriesgo DROP CONSTRAINT riesgo_cargoriesgo_pkey;
ALTER TABLE ONLY public.riesgo_cargoriesgo DROP CONSTRAINT riesgo_cargoriesgo_cargo_id_key;
ALTER TABLE ONLY public.riesgo_cargoriesgo_aproteger DROP CONSTRAINT riesgo_cargoriesgo_aproteger_pkey;
ALTER TABLE ONLY public.riesgo_cargoriesgo_aproteger DROP CONSTRAINT riesgo_cargoriesgo_aproteger_cargoriesgo_id_3a08f318_uniq;
ALTER TABLE ONLY public.norma_norma DROP CONSTRAINT norma_norma_pkey;
ALTER TABLE ONLY public.norma_item DROP CONSTRAINT norma_item_pkey;
ALTER TABLE ONLY public.norma_formato DROP CONSTRAINT norma_formato_pkey;
ALTER TABLE ONLY public.norma_formato DROP CONSTRAINT norma_formato_formulario_digital_id_key;
ALTER TABLE ONLY public.formulario_valor DROP CONSTRAINT formulario_valor_pkey;
ALTER TABLE ONLY public.formulario_tipo DROP CONSTRAINT formulario_tipo_pkey;
ALTER TABLE ONLY public.formulario_revision DROP CONSTRAINT formulario_revision_registro_id_0883997d_uniq;
ALTER TABLE ONLY public.formulario_revision DROP CONSTRAINT formulario_revision_pkey;
ALTER TABLE ONLY public.formulario_registro DROP CONSTRAINT formulario_registro_pkey;
ALTER TABLE ONLY public.formulario_registro DROP CONSTRAINT formulario_registro_correccion_de_id_key;
ALTER TABLE ONLY public.formulario_grupo DROP CONSTRAINT formulario_grupo_pkey;
ALTER TABLE ONLY public.formulario_formulario DROP CONSTRAINT formulario_formulario_pkey;
ALTER TABLE ONLY public.formulario_entrada DROP CONSTRAINT formulario_entrada_pkey;
ALTER TABLE ONLY public.formulario_campo DROP CONSTRAINT formulario_campo_pkey;
ALTER TABLE ONLY public.epc_tipoadquisiscion DROP CONSTRAINT epc_tipoadquisiscion_pkey;
ALTER TABLE ONLY public.epc_proyecto DROP CONSTRAINT epc_proyecto_pkey;
ALTER TABLE ONLY public.epc_progresografico DROP CONSTRAINT epc_progresografico_pkey;
ALTER TABLE ONLY public.epc_progresografico DROP CONSTRAINT epc_progresografico_orden_id_key;
ALTER TABLE ONLY public.epc_ordentrabajo DROP CONSTRAINT epc_ordentrabajo_pkey;
ALTER TABLE ONLY public.epc_ordentrabajo_dependencias DROP CONSTRAINT epc_ordentrabajo_dependencias_pkey;
ALTER TABLE ONLY public.epc_ordentrabajo_dependencias DROP CONSTRAINT epc_ordentrabajo_dependencia_from_ordentrabajo_id_c5144205_uniq;
ALTER TABLE ONLY public.epc_material DROP CONSTRAINT epc_material_pkey;
ALTER TABLE ONLY public.epc_invitacion DROP CONSTRAINT epc_invitacion_pkey;
ALTER TABLE ONLY public.epc_grupo DROP CONSTRAINT epc_grupo_pkey;
ALTER TABLE ONLY public.epc_gantt DROP CONSTRAINT epc_gantt_proyecto_id_key;
ALTER TABLE ONLY public.epc_gantt DROP CONSTRAINT epc_gantt_pkey;
ALTER TABLE ONLY public.epc_personal DROP CONSTRAINT epc_contratista_pkey;
ALTER TABLE ONLY public.epc_adquisiscionmaterial DROP CONSTRAINT epc_adquisiscionmaterial_pkey;
ALTER TABLE ONLY public.epc_actividad DROP CONSTRAINT epc_actividad_pkey;
ALTER TABLE ONLY public.empresa_requisito DROP CONSTRAINT empresa_requisito_pkey;
ALTER TABLE ONLY public.empresa_requisito DROP CONSTRAINT empresa_requisito_cargo_id_key;
ALTER TABLE ONLY public.empresa_liquidacionnomina DROP CONSTRAINT empresa_liquidacionnomina_pkey;
ALTER TABLE ONLY public.empresa_jefes DROP CONSTRAINT empresa_jefes_pkey;
ALTER TABLE ONLY public.empresa_jefes DROP CONSTRAINT empresa_jefes_empleado_id_key;
ALTER TABLE ONLY public.empresa_jefes DROP CONSTRAINT empresa_jefes_departamento_id_key;
ALTER TABLE ONLY public.empresa_horasextra DROP CONSTRAINT empresa_horasextra_pkey;
ALTER TABLE ONLY public.empresa_empresa DROP CONSTRAINT empresa_empresa_pkey;
ALTER TABLE ONLY public.empresa_empresa DROP CONSTRAINT empresa_empresa_configuracion_id_key;
ALTER TABLE ONLY public.empresa_empleado DROP CONSTRAINT empresa_empleado_pkey;
ALTER TABLE ONLY public.empresa_departamento DROP CONSTRAINT empresa_departamento_pkey;
ALTER TABLE ONLY public.empresa_contrato DROP CONSTRAINT empresa_contrato_pkey;
ALTER TABLE ONLY public.empresa_configuracion DROP CONSTRAINT empresa_configuracion_pkey;
ALTER TABLE ONLY public.empresa_cargo DROP CONSTRAINT empresa_cargo_pkey;
ALTER TABLE ONLY public.empresa_calculos DROP CONSTRAINT empresa_calculos_pkey;
ALTER TABLE ONLY public.empresa_asistencia DROP CONSTRAINT empresa_asistencia_pkey;
ALTER TABLE ONLY public.empresa_anio DROP CONSTRAINT empresa_anio_pkey;
ALTER TABLE ONLY public.django_session DROP CONSTRAINT django_session_pkey;
ALTER TABLE ONLY public.django_migrations DROP CONSTRAINT django_migrations_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_pkey;
ALTER TABLE ONLY public.django_content_type DROP CONSTRAINT django_content_type_app_label_76bd3d3b_uniq;
ALTER TABLE ONLY public.django_admin_log DROP CONSTRAINT django_admin_log_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_username_key;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq;
ALTER TABLE ONLY public.auth_user_user_permissions DROP CONSTRAINT auth_user_user_permissions_pkey;
ALTER TABLE ONLY public.auth_user DROP CONSTRAINT auth_user_pkey;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_user_id_94350c0c_uniq;
ALTER TABLE ONLY public.auth_user_groups DROP CONSTRAINT auth_user_groups_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_pkey;
ALTER TABLE ONLY public.auth_permission DROP CONSTRAINT auth_permission_content_type_id_01ab375a_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_pkey;
ALTER TABLE ONLY public.auth_group_permissions DROP CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq;
ALTER TABLE ONLY public.auth_group DROP CONSTRAINT auth_group_name_key;
ALTER TABLE public.validable_validable ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.validable_template ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.usr_auditor ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.usr_administrador ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.riesgo_riesgo_aproteger ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.riesgo_riesgo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.riesgo_evaluacionriesgos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.riesgo_evaluacionempresa ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.riesgo_elementoproteger ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.riesgo_criticidad ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.riesgo_cargoriesgo_aproteger ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.riesgo_cargoriesgo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.norma_norma ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.norma_item ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.norma_formato ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formulario_valor ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formulario_tipo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formulario_revision ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formulario_registro ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formulario_grupo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formulario_formulario ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formulario_entrada ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.formulario_campo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_tipoadquisiscion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_proyecto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_progresografico ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_personal ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_ordentrabajo_dependencias ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_ordentrabajo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_material ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_invitacion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_grupo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_gantt ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_adquisiscionmaterial ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.epc_actividad ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_requisito ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_liquidacionnomina ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_jefes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_horasextra ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_empresa ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_empleado ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_departamento ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_contrato ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_configuracion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_cargo ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_calculos ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_asistencia ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.empresa_anio ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_content_type ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.django_admin_log ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user_groups ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_user ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_permission ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group_permissions ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.auth_group ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.validable_validable_id_seq;
DROP TABLE public.validable_validable;
DROP SEQUENCE public.validable_template_id_seq;
DROP TABLE public.validable_template;
DROP TABLE public.usr_empresa;
DROP TABLE public.usr_empleado;
DROP SEQUENCE public.usr_auditor_id_seq;
DROP TABLE public.usr_auditor;
DROP SEQUENCE public.usr_administrador_id_seq;
DROP TABLE public.usr_administrador;
DROP SEQUENCE public.riesgo_riesgo_id_seq;
DROP SEQUENCE public.riesgo_riesgo_aproteger_id_seq;
DROP TABLE public.riesgo_riesgo_aproteger;
DROP TABLE public.riesgo_riesgo;
DROP SEQUENCE public.riesgo_evaluacionriesgos_id_seq;
DROP TABLE public.riesgo_evaluacionriesgos;
DROP SEQUENCE public.riesgo_evaluacionempresa_id_seq;
DROP TABLE public.riesgo_evaluacionempresa;
DROP SEQUENCE public.riesgo_elementoproteger_id_seq;
DROP TABLE public.riesgo_elementoproteger;
DROP SEQUENCE public.riesgo_criticidad_id_seq;
DROP TABLE public.riesgo_criticidad;
DROP SEQUENCE public.riesgo_cargoriesgo_id_seq;
DROP SEQUENCE public.riesgo_cargoriesgo_aproteger_id_seq;
DROP TABLE public.riesgo_cargoriesgo_aproteger;
DROP TABLE public.riesgo_cargoriesgo;
DROP SEQUENCE public.norma_norma_id_seq;
DROP TABLE public.norma_norma;
DROP SEQUENCE public.norma_item_id_seq;
DROP TABLE public.norma_item;
DROP SEQUENCE public.norma_formato_id_seq;
DROP TABLE public.norma_formato;
DROP SEQUENCE public.formulario_valor_id_seq;
DROP TABLE public.formulario_valor;
DROP SEQUENCE public.formulario_tipo_id_seq;
DROP TABLE public.formulario_tipo;
DROP SEQUENCE public.formulario_revision_id_seq;
DROP TABLE public.formulario_revision;
DROP SEQUENCE public.formulario_registro_id_seq;
DROP TABLE public.formulario_registro;
DROP SEQUENCE public.formulario_grupo_id_seq;
DROP TABLE public.formulario_grupo;
DROP SEQUENCE public.formulario_formulario_id_seq;
DROP TABLE public.formulario_formulario;
DROP SEQUENCE public.formulario_entrada_id_seq;
DROP TABLE public.formulario_entrada;
DROP SEQUENCE public.formulario_campo_id_seq;
DROP TABLE public.formulario_campo;
DROP SEQUENCE public.epc_tipoadquisiscion_id_seq;
DROP TABLE public.epc_tipoadquisiscion;
DROP SEQUENCE public.epc_proyecto_id_seq;
DROP TABLE public.epc_proyecto;
DROP SEQUENCE public.epc_progresografico_id_seq;
DROP TABLE public.epc_progresografico;
DROP SEQUENCE public.epc_ordentrabajo_id_seq;
DROP SEQUENCE public.epc_ordentrabajo_dependencias_id_seq;
DROP TABLE public.epc_ordentrabajo_dependencias;
DROP TABLE public.epc_ordentrabajo;
DROP SEQUENCE public.epc_material_id_seq;
DROP TABLE public.epc_material;
DROP SEQUENCE public.epc_invitacion_id_seq;
DROP TABLE public.epc_invitacion;
DROP SEQUENCE public.epc_grupo_id_seq;
DROP TABLE public.epc_grupo;
DROP SEQUENCE public.epc_gantt_id_seq;
DROP TABLE public.epc_gantt;
DROP SEQUENCE public.epc_contratista_id_seq;
DROP TABLE public.epc_personal;
DROP SEQUENCE public.epc_adquisiscionmaterial_id_seq;
DROP TABLE public.epc_adquisiscionmaterial;
DROP SEQUENCE public.epc_actividad_id_seq;
DROP TABLE public.epc_actividad;
DROP SEQUENCE public.empresa_requisito_id_seq;
DROP TABLE public.empresa_requisito;
DROP SEQUENCE public.empresa_liquidacionnomina_id_seq;
DROP TABLE public.empresa_liquidacionnomina;
DROP SEQUENCE public.empresa_jefes_id_seq;
DROP TABLE public.empresa_jefes;
DROP SEQUENCE public.empresa_horasextra_id_seq;
DROP TABLE public.empresa_horasextra;
DROP SEQUENCE public.empresa_empresa_id_seq;
DROP TABLE public.empresa_empresa;
DROP SEQUENCE public.empresa_empleado_id_seq;
DROP TABLE public.empresa_empleado;
DROP SEQUENCE public.empresa_departamento_id_seq;
DROP TABLE public.empresa_departamento;
DROP SEQUENCE public.empresa_contrato_id_seq;
DROP TABLE public.empresa_contrato;
DROP SEQUENCE public.empresa_configuracion_id_seq;
DROP TABLE public.empresa_configuracion;
DROP SEQUENCE public.empresa_cargo_id_seq;
DROP TABLE public.empresa_cargo;
DROP SEQUENCE public.empresa_calculos_id_seq;
DROP TABLE public.empresa_calculos;
DROP SEQUENCE public.empresa_asistencia_id_seq;
DROP TABLE public.empresa_asistencia;
DROP SEQUENCE public.empresa_anio_id_seq;
DROP TABLE public.empresa_anio;
DROP TABLE public.django_session;
DROP SEQUENCE public.django_migrations_id_seq;
DROP TABLE public.django_migrations;
DROP SEQUENCE public.django_content_type_id_seq;
DROP TABLE public.django_content_type;
DROP SEQUENCE public.django_admin_log_id_seq;
DROP TABLE public.django_admin_log;
DROP SEQUENCE public.auth_user_user_permissions_id_seq;
DROP TABLE public.auth_user_user_permissions;
DROP SEQUENCE public.auth_user_id_seq;
DROP SEQUENCE public.auth_user_groups_id_seq;
DROP TABLE public.auth_user_groups;
DROP TABLE public.auth_user;
DROP SEQUENCE public.auth_permission_id_seq;
DROP TABLE public.auth_permission;
DROP SEQUENCE public.auth_group_permissions_id_seq;
DROP TABLE public.auth_group_permissions;
DROP SEQUENCE public.auth_group_id_seq;
DROP TABLE public.auth_group;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_migrations (
    id integer NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE django_migrations OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE django_migrations_id_seq OWNER TO postgres;

--
-- Name: django_migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_migrations_id_seq OWNED BY django_migrations.id;


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE django_session OWNER TO postgres;

--
-- Name: empresa_anio; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_anio (
    id integer NOT NULL,
    anio integer NOT NULL
);


ALTER TABLE empresa_anio OWNER TO postgres;

--
-- Name: empresa_anio_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_anio_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_anio_id_seq OWNER TO postgres;

--
-- Name: empresa_anio_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_anio_id_seq OWNED BY empresa_anio.id;


--
-- Name: empresa_asistencia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_asistencia (
    id integer NOT NULL,
    fecha timestamp with time zone NOT NULL,
    periodo integer NOT NULL,
    semestre integer NOT NULL,
    contrato_id integer NOT NULL,
    empleado_id integer NOT NULL
);


ALTER TABLE empresa_asistencia OWNER TO postgres;

--
-- Name: empresa_asistencia_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_asistencia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_asistencia_id_seq OWNER TO postgres;

--
-- Name: empresa_asistencia_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_asistencia_id_seq OWNED BY empresa_asistencia.id;


--
-- Name: empresa_calculos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_calculos (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    cesa character varying(100),
    intc character varying(100),
    prim character varying(100),
    vaca character varying(100),
    hexd character varying(100),
    hnoc character varying(100),
    hexn character varying(100),
    hord character varying(100),
    hxdd character varying(100),
    hxnd character varying(100)
);


ALTER TABLE empresa_calculos OWNER TO postgres;

--
-- Name: empresa_calculos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_calculos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_calculos_id_seq OWNER TO postgres;

--
-- Name: empresa_calculos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_calculos_id_seq OWNED BY empresa_calculos.id;


--
-- Name: empresa_cargo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_cargo (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    activo boolean NOT NULL,
    descripcion text NOT NULL,
    salario numeric(20,3) NOT NULL,
    departamento_id integer NOT NULL
);


ALTER TABLE empresa_cargo OWNER TO postgres;

--
-- Name: empresa_cargo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_cargo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_cargo_id_seq OWNER TO postgres;

--
-- Name: empresa_cargo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_cargo_id_seq OWNED BY empresa_cargo.id;


--
-- Name: empresa_configuracion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_configuracion (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    dias_anio integer NOT NULL,
    porc_cesa double precision NOT NULL,
    ango_vaca integer NOT NULL,
    porc_hexd double precision NOT NULL,
    porc_hnoc double precision NOT NULL,
    porc_hexn double precision NOT NULL,
    porc_hord double precision NOT NULL,
    porc_hxdd double precision NOT NULL,
    porc_hxnd double precision NOT NULL,
    agno_vaca double precision NOT NULL,
    dia_cmes integer NOT NULL,
    dia_cqui integer NOT NULL,
    dia_canu integer NOT NULL,
    mes_canu integer NOT NULL
);


ALTER TABLE empresa_configuracion OWNER TO postgres;

--
-- Name: empresa_configuracion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_configuracion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_configuracion_id_seq OWNER TO postgres;

--
-- Name: empresa_configuracion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_configuracion_id_seq OWNED BY empresa_configuracion.id;


--
-- Name: empresa_contrato; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_contrato (
    id integer NOT NULL,
    fecha date NOT NULL,
    fecha_inicio date NOT NULL,
    documento character varying(100) NOT NULL,
    firmado boolean NOT NULL,
    horas_dia integer NOT NULL,
    modalidad integer NOT NULL,
    fecha_vencimiento date,
    cargo_id integer NOT NULL,
    empleado_id integer NOT NULL
);


ALTER TABLE empresa_contrato OWNER TO postgres;

--
-- Name: empresa_contrato_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_contrato_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_contrato_id_seq OWNER TO postgres;

--
-- Name: empresa_contrato_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_contrato_id_seq OWNED BY empresa_contrato.id;


--
-- Name: empresa_departamento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_departamento (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    codigo character varying(3) NOT NULL,
    activo boolean NOT NULL,
    empresa_id integer NOT NULL,
    superior_id integer
);


ALTER TABLE empresa_departamento OWNER TO postgres;

--
-- Name: empresa_departamento_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_departamento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_departamento_id_seq OWNER TO postgres;

--
-- Name: empresa_departamento_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_departamento_id_seq OWNED BY empresa_departamento.id;


--
-- Name: empresa_empleado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_empleado (
    id integer NOT NULL,
    codigo character varying(10) NOT NULL,
    nombre character varying(100) NOT NULL,
    apellido character varying(100) NOT NULL,
    telefono character varying(12) NOT NULL,
    bonificacion numeric(20,2) NOT NULL,
    cargo_id integer,
    empresa_id integer NOT NULL
);


ALTER TABLE empresa_empleado OWNER TO postgres;

--
-- Name: empresa_empleado_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_empleado_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_empleado_id_seq OWNER TO postgres;

--
-- Name: empresa_empleado_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_empleado_id_seq OWNED BY empresa_empleado.id;


--
-- Name: empresa_empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_empresa (
    id integer NOT NULL,
    codigo character varying(3) NOT NULL,
    razons character varying(100) NOT NULL,
    ident character varying(30) NOT NULL,
    telefono character varying(20) NOT NULL,
    ciudad character varying(50) NOT NULL,
    activo boolean NOT NULL,
    logo character varying(100) NOT NULL,
    email character varying(254) NOT NULL,
    direccion text NOT NULL,
    calculos_id integer,
    configuracion_id integer
);


ALTER TABLE empresa_empresa OWNER TO postgres;

--
-- Name: empresa_empresa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_empresa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_empresa_id_seq OWNER TO postgres;

--
-- Name: empresa_empresa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_empresa_id_seq OWNED BY empresa_empresa.id;


--
-- Name: empresa_horasextra; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_horasextra (
    id integer NOT NULL,
    fecha timestamp with time zone NOT NULL,
    periodo integer NOT NULL,
    semestre integer NOT NULL,
    horas integer NOT NULL,
    tipo boolean NOT NULL,
    dominical boolean NOT NULL,
    contrato_id integer NOT NULL,
    empleado_id integer NOT NULL
);


ALTER TABLE empresa_horasextra OWNER TO postgres;

--
-- Name: empresa_horasextra_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_horasextra_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_horasextra_id_seq OWNER TO postgres;

--
-- Name: empresa_horasextra_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_horasextra_id_seq OWNED BY empresa_horasextra.id;


--
-- Name: empresa_jefes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_jefes (
    id integer NOT NULL,
    departamento_id integer NOT NULL,
    empleado_id integer NOT NULL
);


ALTER TABLE empresa_jefes OWNER TO postgres;

--
-- Name: empresa_jefes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_jefes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_jefes_id_seq OWNER TO postgres;

--
-- Name: empresa_jefes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_jefes_id_seq OWNED BY empresa_jefes.id;


--
-- Name: empresa_liquidacionnomina; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_liquidacionnomina (
    id integer NOT NULL,
    periodo integer NOT NULL,
    semestre integer NOT NULL,
    fecha date NOT NULL,
    fecha_corte date NOT NULL,
    dias integer NOT NULL,
    cesa numeric(20,2),
    intc numeric(20,2),
    prim numeric(20,2),
    hord numeric(20,2),
    hexd numeric(20,2),
    hexn numeric(20,2),
    hxdd numeric(20,2),
    hxnd numeric(20,2),
    totl numeric(20,2),
    contrato_id integer NOT NULL,
    empleado_id integer NOT NULL
);


ALTER TABLE empresa_liquidacionnomina OWNER TO postgres;

--
-- Name: empresa_liquidacionnomina_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_liquidacionnomina_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_liquidacionnomina_id_seq OWNER TO postgres;

--
-- Name: empresa_liquidacionnomina_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_liquidacionnomina_id_seq OWNED BY empresa_liquidacionnomina.id;


--
-- Name: empresa_requisito; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE empresa_requisito (
    id integer NOT NULL,
    educacion text NOT NULL,
    formacion text NOT NULL,
    habilidades text NOT NULL,
    experiencia text NOT NULL,
    cargo_id integer
);


ALTER TABLE empresa_requisito OWNER TO postgres;

--
-- Name: empresa_requisito_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE empresa_requisito_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE empresa_requisito_id_seq OWNER TO postgres;

--
-- Name: empresa_requisito_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE empresa_requisito_id_seq OWNED BY empresa_requisito.id;


--
-- Name: epc_actividad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_actividad (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    completado boolean NOT NULL,
    fecha_completado date,
    orden_id integer NOT NULL,
    dias_estimados integer NOT NULL,
    poscicion integer NOT NULL,
    formato_id integer,
    registro_id integer,
    CONSTRAINT epc_actividad_poscicion_5721017e_check CHECK ((poscicion >= 0))
);


ALTER TABLE epc_actividad OWNER TO postgres;

--
-- Name: epc_actividad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_actividad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_actividad_id_seq OWNER TO postgres;

--
-- Name: epc_actividad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_actividad_id_seq OWNED BY epc_actividad.id;


--
-- Name: epc_adquisiscionmaterial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_adquisiscionmaterial (
    id integer NOT NULL,
    precio numeric(15,2) NOT NULL,
    material_id integer NOT NULL,
    orden_id integer NOT NULL,
    tipo_id integer NOT NULL
);


ALTER TABLE epc_adquisiscionmaterial OWNER TO postgres;

--
-- Name: epc_adquisiscionmaterial_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_adquisiscionmaterial_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_adquisiscionmaterial_id_seq OWNER TO postgres;

--
-- Name: epc_adquisiscionmaterial_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_adquisiscionmaterial_id_seq OWNED BY epc_adquisiscionmaterial.id;


--
-- Name: epc_personal; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_personal (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    empleado_id integer
);


ALTER TABLE epc_personal OWNER TO postgres;

--
-- Name: epc_contratista_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_contratista_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_contratista_id_seq OWNER TO postgres;

--
-- Name: epc_contratista_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_contratista_id_seq OWNED BY epc_personal.id;


--
-- Name: epc_gantt; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_gantt (
    id integer NOT NULL,
    proyecto_id integer NOT NULL
);


ALTER TABLE epc_gantt OWNER TO postgres;

--
-- Name: epc_gantt_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_gantt_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_gantt_id_seq OWNER TO postgres;

--
-- Name: epc_gantt_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_gantt_id_seq OWNED BY epc_gantt.id;


--
-- Name: epc_grupo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_grupo (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE epc_grupo OWNER TO postgres;

--
-- Name: epc_grupo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_grupo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_grupo_id_seq OWNER TO postgres;

--
-- Name: epc_grupo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_grupo_id_seq OWNED BY epc_grupo.id;


--
-- Name: epc_invitacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_invitacion (
    id integer NOT NULL,
    grupo_id integer NOT NULL,
    personal_id integer NOT NULL
);


ALTER TABLE epc_invitacion OWNER TO postgres;

--
-- Name: epc_invitacion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_invitacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_invitacion_id_seq OWNER TO postgres;

--
-- Name: epc_invitacion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_invitacion_id_seq OWNED BY epc_invitacion.id;


--
-- Name: epc_material; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_material (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    uso_unico boolean NOT NULL
);


ALTER TABLE epc_material OWNER TO postgres;

--
-- Name: epc_material_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_material_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_material_id_seq OWNER TO postgres;

--
-- Name: epc_material_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_material_id_seq OWNED BY epc_material.id;


--
-- Name: epc_ordentrabajo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_ordentrabajo (
    id integer NOT NULL,
    nombre_corto character varying(45) NOT NULL,
    fecha date NOT NULL,
    fecha_creacion date NOT NULL,
    personal_id integer NOT NULL,
    proyecto_id integer NOT NULL,
    revisor_id integer NOT NULL
);


ALTER TABLE epc_ordentrabajo OWNER TO postgres;

--
-- Name: epc_ordentrabajo_dependencias; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_ordentrabajo_dependencias (
    id integer NOT NULL,
    from_ordentrabajo_id integer NOT NULL,
    to_ordentrabajo_id integer NOT NULL
);


ALTER TABLE epc_ordentrabajo_dependencias OWNER TO postgres;

--
-- Name: epc_ordentrabajo_dependencias_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_ordentrabajo_dependencias_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_ordentrabajo_dependencias_id_seq OWNER TO postgres;

--
-- Name: epc_ordentrabajo_dependencias_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_ordentrabajo_dependencias_id_seq OWNED BY epc_ordentrabajo_dependencias.id;


--
-- Name: epc_ordentrabajo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_ordentrabajo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_ordentrabajo_id_seq OWNER TO postgres;

--
-- Name: epc_ordentrabajo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_ordentrabajo_id_seq OWNED BY epc_ordentrabajo.id;


--
-- Name: epc_progresografico; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_progresografico (
    id integer NOT NULL,
    orden_id integer NOT NULL
);


ALTER TABLE epc_progresografico OWNER TO postgres;

--
-- Name: epc_progresografico_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_progresografico_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_progresografico_id_seq OWNER TO postgres;

--
-- Name: epc_progresografico_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_progresografico_id_seq OWNED BY epc_progresografico.id;


--
-- Name: epc_proyecto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_proyecto (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL,
    grupo_id integer
);


ALTER TABLE epc_proyecto OWNER TO postgres;

--
-- Name: epc_proyecto_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_proyecto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_proyecto_id_seq OWNER TO postgres;

--
-- Name: epc_proyecto_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_proyecto_id_seq OWNED BY epc_proyecto.id;


--
-- Name: epc_tipoadquisiscion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE epc_tipoadquisiscion (
    id integer NOT NULL,
    nombre character varying(100) NOT NULL
);


ALTER TABLE epc_tipoadquisiscion OWNER TO postgres;

--
-- Name: epc_tipoadquisiscion_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE epc_tipoadquisiscion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE epc_tipoadquisiscion_id_seq OWNER TO postgres;

--
-- Name: epc_tipoadquisiscion_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE epc_tipoadquisiscion_id_seq OWNED BY epc_tipoadquisiscion.id;


--
-- Name: formulario_campo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE formulario_campo (
    id integer NOT NULL,
    nombre character varying(45) NOT NULL,
    tipo_id integer NOT NULL,
    grupo_id integer NOT NULL,
    ver_como character varying(45) NOT NULL
);


ALTER TABLE formulario_campo OWNER TO postgres;

--
-- Name: formulario_campo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formulario_campo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formulario_campo_id_seq OWNER TO postgres;

--
-- Name: formulario_campo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formulario_campo_id_seq OWNED BY formulario_campo.id;


--
-- Name: formulario_entrada; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE formulario_entrada (
    id integer NOT NULL,
    campo_id integer NOT NULL,
    registro_id integer NOT NULL,
    valor_id integer
);


ALTER TABLE formulario_entrada OWNER TO postgres;

--
-- Name: formulario_entrada_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formulario_entrada_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formulario_entrada_id_seq OWNER TO postgres;

--
-- Name: formulario_entrada_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formulario_entrada_id_seq OWNED BY formulario_entrada.id;


--
-- Name: formulario_formulario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE formulario_formulario (
    id integer NOT NULL,
    nombre character varying(45) NOT NULL,
    fecha timestamp with time zone NOT NULL
);


ALTER TABLE formulario_formulario OWNER TO postgres;

--
-- Name: formulario_formulario_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formulario_formulario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formulario_formulario_id_seq OWNER TO postgres;

--
-- Name: formulario_formulario_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formulario_formulario_id_seq OWNED BY formulario_formulario.id;


--
-- Name: formulario_grupo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE formulario_grupo (
    id integer NOT NULL,
    nombre character varying(145) NOT NULL,
    formulario_id integer NOT NULL
);


ALTER TABLE formulario_grupo OWNER TO postgres;

--
-- Name: formulario_grupo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formulario_grupo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formulario_grupo_id_seq OWNER TO postgres;

--
-- Name: formulario_grupo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formulario_grupo_id_seq OWNED BY formulario_grupo.id;


--
-- Name: formulario_registro; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE formulario_registro (
    id integer NOT NULL,
    completado boolean NOT NULL,
    fecha timestamp with time zone,
    empleado_id integer NOT NULL,
    formulario_id integer NOT NULL,
    revisor_id integer NOT NULL,
    correccion_de_id integer
);


ALTER TABLE formulario_registro OWNER TO postgres;

--
-- Name: formulario_registro_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formulario_registro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formulario_registro_id_seq OWNER TO postgres;

--
-- Name: formulario_registro_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formulario_registro_id_seq OWNED BY formulario_registro.id;


--
-- Name: formulario_revision; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE formulario_revision (
    id integer NOT NULL,
    fecha timestamp with time zone NOT NULL,
    revision boolean,
    comentario text NOT NULL,
    registro_id integer NOT NULL
);


ALTER TABLE formulario_revision OWNER TO postgres;

--
-- Name: formulario_revision_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formulario_revision_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formulario_revision_id_seq OWNER TO postgres;

--
-- Name: formulario_revision_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formulario_revision_id_seq OWNED BY formulario_revision.id;


--
-- Name: formulario_tipo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE formulario_tipo (
    id integer NOT NULL,
    forma integer NOT NULL,
    nombre character varying(45) NOT NULL,
    regular character varying(100)
);


ALTER TABLE formulario_tipo OWNER TO postgres;

--
-- Name: formulario_tipo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formulario_tipo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formulario_tipo_id_seq OWNER TO postgres;

--
-- Name: formulario_tipo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formulario_tipo_id_seq OWNED BY formulario_tipo.id;


--
-- Name: formulario_valor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE formulario_valor (
    id integer NOT NULL,
    valor bytea NOT NULL,
    tipo_id integer NOT NULL
);


ALTER TABLE formulario_valor OWNER TO postgres;

--
-- Name: formulario_valor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE formulario_valor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE formulario_valor_id_seq OWNER TO postgres;

--
-- Name: formulario_valor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE formulario_valor_id_seq OWNED BY formulario_valor.id;


--
-- Name: norma_formato; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE norma_formato (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion text NOT NULL,
    documento character varying(100),
    ejemplo character varying(100),
    formulario_digital_id integer,
    item_id integer NOT NULL
);


ALTER TABLE norma_formato OWNER TO postgres;

--
-- Name: norma_formato_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE norma_formato_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE norma_formato_id_seq OWNER TO postgres;

--
-- Name: norma_formato_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE norma_formato_id_seq OWNED BY norma_formato.id;


--
-- Name: norma_item; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE norma_item (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion text NOT NULL,
    norma_id integer NOT NULL
);


ALTER TABLE norma_item OWNER TO postgres;

--
-- Name: norma_item_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE norma_item_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE norma_item_id_seq OWNER TO postgres;

--
-- Name: norma_item_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE norma_item_id_seq OWNED BY norma_item.id;


--
-- Name: norma_norma; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE norma_norma (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    edicion character varying(50) NOT NULL,
    fecha_edicion date NOT NULL,
    referencia character varying(100) NOT NULL,
    activo boolean NOT NULL
);


ALTER TABLE norma_norma OWNER TO postgres;

--
-- Name: norma_norma_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE norma_norma_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE norma_norma_id_seq OWNER TO postgres;

--
-- Name: norma_norma_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE norma_norma_id_seq OWNED BY norma_norma.id;


--
-- Name: riesgo_cargoriesgo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE riesgo_cargoriesgo (
    id integer NOT NULL,
    acceso integer,
    impacto integer,
    contacto_aproteger integer,
    manejo_programas integer,
    incidencia_medidas integer,
    ponderacion double precision,
    calificacion integer,
    cargo_id integer NOT NULL,
    criticidad_id integer NOT NULL
);


ALTER TABLE riesgo_cargoriesgo OWNER TO postgres;

--
-- Name: riesgo_cargoriesgo_aproteger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE riesgo_cargoriesgo_aproteger (
    id integer NOT NULL,
    cargoriesgo_id integer NOT NULL,
    elementoproteger_id integer NOT NULL
);


ALTER TABLE riesgo_cargoriesgo_aproteger OWNER TO postgres;

--
-- Name: riesgo_cargoriesgo_aproteger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE riesgo_cargoriesgo_aproteger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE riesgo_cargoriesgo_aproteger_id_seq OWNER TO postgres;

--
-- Name: riesgo_cargoriesgo_aproteger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE riesgo_cargoriesgo_aproteger_id_seq OWNED BY riesgo_cargoriesgo_aproteger.id;


--
-- Name: riesgo_cargoriesgo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE riesgo_cargoriesgo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE riesgo_cargoriesgo_id_seq OWNER TO postgres;

--
-- Name: riesgo_cargoriesgo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE riesgo_cargoriesgo_id_seq OWNED BY riesgo_cargoriesgo.id;


--
-- Name: riesgo_criticidad; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE riesgo_criticidad (
    id integer NOT NULL,
    nombre character varying(20) NOT NULL,
    descripcion text NOT NULL
);


ALTER TABLE riesgo_criticidad OWNER TO postgres;

--
-- Name: riesgo_criticidad_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE riesgo_criticidad_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE riesgo_criticidad_id_seq OWNER TO postgres;

--
-- Name: riesgo_criticidad_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE riesgo_criticidad_id_seq OWNED BY riesgo_criticidad.id;


--
-- Name: riesgo_elementoproteger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE riesgo_elementoproteger (
    id integer NOT NULL,
    nombre character varying(50) NOT NULL,
    descripcion text NOT NULL
);


ALTER TABLE riesgo_elementoproteger OWNER TO postgres;

--
-- Name: riesgo_elementoproteger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE riesgo_elementoproteger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE riesgo_elementoproteger_id_seq OWNER TO postgres;

--
-- Name: riesgo_elementoproteger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE riesgo_elementoproteger_id_seq OWNED BY riesgo_elementoproteger.id;


--
-- Name: riesgo_evaluacionempresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE riesgo_evaluacionempresa (
    id integer NOT NULL,
    fecha timestamp with time zone NOT NULL,
    aprobado boolean NOT NULL,
    empresa_id integer NOT NULL
);


ALTER TABLE riesgo_evaluacionempresa OWNER TO postgres;

--
-- Name: riesgo_evaluacionempresa_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE riesgo_evaluacionempresa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE riesgo_evaluacionempresa_id_seq OWNER TO postgres;

--
-- Name: riesgo_evaluacionempresa_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE riesgo_evaluacionempresa_id_seq OWNED BY riesgo_evaluacionempresa.id;


--
-- Name: riesgo_evaluacionriesgos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE riesgo_evaluacionriesgos (
    id integer NOT NULL,
    fuente text,
    medio text,
    persona text,
    metodo text,
    probabilidad integer,
    consecuencia integer,
    controles_administrativos text,
    controles_operacionales text,
    "controles_talentoHumano" text,
    controles_instalacion text,
    empresa_id integer,
    riesgo_id integer
);


ALTER TABLE riesgo_evaluacionriesgos OWNER TO postgres;

--
-- Name: riesgo_evaluacionriesgos_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE riesgo_evaluacionriesgos_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE riesgo_evaluacionriesgos_id_seq OWNER TO postgres;

--
-- Name: riesgo_evaluacionriesgos_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE riesgo_evaluacionriesgos_id_seq OWNED BY riesgo_evaluacionriesgos.id;


--
-- Name: riesgo_riesgo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE riesgo_riesgo (
    id integer NOT NULL,
    amenaza text NOT NULL,
    riesgo text NOT NULL,
    empresa_id integer NOT NULL
);


ALTER TABLE riesgo_riesgo OWNER TO postgres;

--
-- Name: riesgo_riesgo_aproteger; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE riesgo_riesgo_aproteger (
    id integer NOT NULL,
    riesgo_id integer NOT NULL,
    elementoproteger_id integer NOT NULL
);


ALTER TABLE riesgo_riesgo_aproteger OWNER TO postgres;

--
-- Name: riesgo_riesgo_aproteger_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE riesgo_riesgo_aproteger_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE riesgo_riesgo_aproteger_id_seq OWNER TO postgres;

--
-- Name: riesgo_riesgo_aproteger_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE riesgo_riesgo_aproteger_id_seq OWNED BY riesgo_riesgo_aproteger.id;


--
-- Name: riesgo_riesgo_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE riesgo_riesgo_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE riesgo_riesgo_id_seq OWNER TO postgres;

--
-- Name: riesgo_riesgo_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE riesgo_riesgo_id_seq OWNED BY riesgo_riesgo.id;


--
-- Name: usr_administrador; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE usr_administrador (
    id integer NOT NULL,
    usuario_id integer NOT NULL
);


ALTER TABLE usr_administrador OWNER TO postgres;

--
-- Name: usr_administrador_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE usr_administrador_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE usr_administrador_id_seq OWNER TO postgres;

--
-- Name: usr_administrador_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE usr_administrador_id_seq OWNED BY usr_administrador.id;


--
-- Name: usr_auditor; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE usr_auditor (
    id integer NOT NULL,
    usuario_id integer NOT NULL
);


ALTER TABLE usr_auditor OWNER TO postgres;

--
-- Name: usr_auditor_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE usr_auditor_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE usr_auditor_id_seq OWNER TO postgres;

--
-- Name: usr_auditor_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE usr_auditor_id_seq OWNED BY usr_auditor.id;


--
-- Name: usr_empleado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE usr_empleado (
    user_ptr_id integer NOT NULL,
    _empleado_id integer NOT NULL
);


ALTER TABLE usr_empleado OWNER TO postgres;

--
-- Name: usr_empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE usr_empresa (
    user_ptr_id integer NOT NULL,
    _empresa_id integer NOT NULL
);


ALTER TABLE usr_empresa OWNER TO postgres;

--
-- Name: validable_template; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE validable_template (
    id integer NOT NULL,
    template bytea NOT NULL,
    validable_id integer NOT NULL
);


ALTER TABLE validable_template OWNER TO postgres;

--
-- Name: validable_template_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE validable_template_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE validable_template_id_seq OWNER TO postgres;

--
-- Name: validable_template_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE validable_template_id_seq OWNED BY validable_template.id;


--
-- Name: validable_validable; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE validable_validable (
    id integer NOT NULL,
    activo boolean NOT NULL,
    identificador character varying(45),
    class_name character varying(45)
);


ALTER TABLE validable_validable OWNER TO postgres;

--
-- Name: validable_validable_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE validable_validable_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE validable_validable_id_seq OWNER TO postgres;

--
-- Name: validable_validable_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE validable_validable_id_seq OWNED BY validable_validable.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_migrations ALTER COLUMN id SET DEFAULT nextval('django_migrations_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_anio ALTER COLUMN id SET DEFAULT nextval('empresa_anio_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_asistencia ALTER COLUMN id SET DEFAULT nextval('empresa_asistencia_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_calculos ALTER COLUMN id SET DEFAULT nextval('empresa_calculos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_cargo ALTER COLUMN id SET DEFAULT nextval('empresa_cargo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_configuracion ALTER COLUMN id SET DEFAULT nextval('empresa_configuracion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_contrato ALTER COLUMN id SET DEFAULT nextval('empresa_contrato_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_departamento ALTER COLUMN id SET DEFAULT nextval('empresa_departamento_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_empleado ALTER COLUMN id SET DEFAULT nextval('empresa_empleado_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_empresa ALTER COLUMN id SET DEFAULT nextval('empresa_empresa_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_horasextra ALTER COLUMN id SET DEFAULT nextval('empresa_horasextra_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_jefes ALTER COLUMN id SET DEFAULT nextval('empresa_jefes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_liquidacionnomina ALTER COLUMN id SET DEFAULT nextval('empresa_liquidacionnomina_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_requisito ALTER COLUMN id SET DEFAULT nextval('empresa_requisito_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_actividad ALTER COLUMN id SET DEFAULT nextval('epc_actividad_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_adquisiscionmaterial ALTER COLUMN id SET DEFAULT nextval('epc_adquisiscionmaterial_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_gantt ALTER COLUMN id SET DEFAULT nextval('epc_gantt_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_grupo ALTER COLUMN id SET DEFAULT nextval('epc_grupo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_invitacion ALTER COLUMN id SET DEFAULT nextval('epc_invitacion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_material ALTER COLUMN id SET DEFAULT nextval('epc_material_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_ordentrabajo ALTER COLUMN id SET DEFAULT nextval('epc_ordentrabajo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_ordentrabajo_dependencias ALTER COLUMN id SET DEFAULT nextval('epc_ordentrabajo_dependencias_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_personal ALTER COLUMN id SET DEFAULT nextval('epc_contratista_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_progresografico ALTER COLUMN id SET DEFAULT nextval('epc_progresografico_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_proyecto ALTER COLUMN id SET DEFAULT nextval('epc_proyecto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_tipoadquisiscion ALTER COLUMN id SET DEFAULT nextval('epc_tipoadquisiscion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_campo ALTER COLUMN id SET DEFAULT nextval('formulario_campo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_entrada ALTER COLUMN id SET DEFAULT nextval('formulario_entrada_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_formulario ALTER COLUMN id SET DEFAULT nextval('formulario_formulario_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_grupo ALTER COLUMN id SET DEFAULT nextval('formulario_grupo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_registro ALTER COLUMN id SET DEFAULT nextval('formulario_registro_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_revision ALTER COLUMN id SET DEFAULT nextval('formulario_revision_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_tipo ALTER COLUMN id SET DEFAULT nextval('formulario_tipo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_valor ALTER COLUMN id SET DEFAULT nextval('formulario_valor_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY norma_formato ALTER COLUMN id SET DEFAULT nextval('norma_formato_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY norma_item ALTER COLUMN id SET DEFAULT nextval('norma_item_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY norma_norma ALTER COLUMN id SET DEFAULT nextval('norma_norma_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_cargoriesgo ALTER COLUMN id SET DEFAULT nextval('riesgo_cargoriesgo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_cargoriesgo_aproteger ALTER COLUMN id SET DEFAULT nextval('riesgo_cargoriesgo_aproteger_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_criticidad ALTER COLUMN id SET DEFAULT nextval('riesgo_criticidad_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_elementoproteger ALTER COLUMN id SET DEFAULT nextval('riesgo_elementoproteger_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_evaluacionempresa ALTER COLUMN id SET DEFAULT nextval('riesgo_evaluacionempresa_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_evaluacionriesgos ALTER COLUMN id SET DEFAULT nextval('riesgo_evaluacionriesgos_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_riesgo ALTER COLUMN id SET DEFAULT nextval('riesgo_riesgo_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_riesgo_aproteger ALTER COLUMN id SET DEFAULT nextval('riesgo_riesgo_aproteger_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_administrador ALTER COLUMN id SET DEFAULT nextval('usr_administrador_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_auditor ALTER COLUMN id SET DEFAULT nextval('usr_auditor_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validable_template ALTER COLUMN id SET DEFAULT nextval('validable_template_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validable_validable ALTER COLUMN id SET DEFAULT nextval('validable_validable_id_seq'::regclass);


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group (id, name) FROM stdin;
\.
COPY auth_group (id, name) FROM '$$PATH$$/2872.dat';

--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_id_seq', 3, true);


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.
COPY auth_group_permissions (id, group_id, permission_id) FROM '$$PATH$$/2874.dat';

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
\.
COPY auth_permission (id, name, content_type_id, codename) FROM '$$PATH$$/2870.dat';

--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_permission_id_seq', 159, true);


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
\.
COPY auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM '$$PATH$$/2876.dat';

--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.
COPY auth_user_groups (id, user_id, group_id) FROM '$$PATH$$/2878.dat';

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 3, true);


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_id_seq', 2, true);


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.
COPY auth_user_user_permissions (id, user_id, permission_id) FROM '$$PATH$$/2880.dat';

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.
COPY django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM '$$PATH$$/2882.dat';

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 247, true);


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_content_type (id, app_label, model) FROM stdin;
\.
COPY django_content_type (id, app_label, model) FROM '$$PATH$$/2868.dat';

--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_content_type_id_seq', 53, true);


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_migrations (id, app, name, applied) FROM stdin;
\.
COPY django_migrations (id, app, name, applied) FROM '$$PATH$$/2866.dat';

--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_migrations_id_seq', 45, true);


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
\.
COPY django_session (session_key, session_data, expire_date) FROM '$$PATH$$/2973.dat';

--
-- Data for Name: empresa_anio; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_anio (id, anio) FROM stdin;
\.
COPY empresa_anio (id, anio) FROM '$$PATH$$/2884.dat';

--
-- Name: empresa_anio_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_anio_id_seq', 1, false);


--
-- Data for Name: empresa_asistencia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_asistencia (id, fecha, periodo, semestre, contrato_id, empleado_id) FROM stdin;
\.
COPY empresa_asistencia (id, fecha, periodo, semestre, contrato_id, empleado_id) FROM '$$PATH$$/2886.dat';

--
-- Name: empresa_asistencia_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_asistencia_id_seq', 1, false);


--
-- Data for Name: empresa_calculos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_calculos (id, nombre, cesa, intc, prim, vaca, hexd, hnoc, hexn, hord, hxdd, hxnd) FROM stdin;
\.
COPY empresa_calculos (id, nombre, cesa, intc, prim, vaca, hexd, hnoc, hexn, hord, hxdd, hxnd) FROM '$$PATH$$/2888.dat';

--
-- Name: empresa_calculos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_calculos_id_seq', 2, true);


--
-- Data for Name: empresa_cargo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_cargo (id, nombre, activo, descripcion, salario, departamento_id) FROM stdin;
\.
COPY empresa_cargo (id, nombre, activo, descripcion, salario, departamento_id) FROM '$$PATH$$/2890.dat';

--
-- Name: empresa_cargo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_cargo_id_seq', 3, true);


--
-- Data for Name: empresa_configuracion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_configuracion (id, nombre, dias_anio, porc_cesa, ango_vaca, porc_hexd, porc_hnoc, porc_hexn, porc_hord, porc_hxdd, porc_hxnd, agno_vaca, dia_cmes, dia_cqui, dia_canu, mes_canu) FROM stdin;
\.
COPY empresa_configuracion (id, nombre, dias_anio, porc_cesa, ango_vaca, porc_hexd, porc_hnoc, porc_hexn, porc_hord, porc_hxdd, porc_hxnd, agno_vaca, dia_cmes, dia_cqui, dia_canu, mes_canu) FROM '$$PATH$$/2892.dat';

--
-- Name: empresa_configuracion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_configuracion_id_seq', 1, true);


--
-- Data for Name: empresa_contrato; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_contrato (id, fecha, fecha_inicio, documento, firmado, horas_dia, modalidad, fecha_vencimiento, cargo_id, empleado_id) FROM stdin;
\.
COPY empresa_contrato (id, fecha, fecha_inicio, documento, firmado, horas_dia, modalidad, fecha_vencimiento, cargo_id, empleado_id) FROM '$$PATH$$/2894.dat';

--
-- Name: empresa_contrato_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_contrato_id_seq', 3, true);


--
-- Data for Name: empresa_departamento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_departamento (id, nombre, codigo, activo, empresa_id, superior_id) FROM stdin;
\.
COPY empresa_departamento (id, nombre, codigo, activo, empresa_id, superior_id) FROM '$$PATH$$/2896.dat';

--
-- Name: empresa_departamento_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_departamento_id_seq', 1, true);


--
-- Data for Name: empresa_empleado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_empleado (id, codigo, nombre, apellido, telefono, bonificacion, cargo_id, empresa_id) FROM stdin;
\.
COPY empresa_empleado (id, codigo, nombre, apellido, telefono, bonificacion, cargo_id, empresa_id) FROM '$$PATH$$/2898.dat';

--
-- Name: empresa_empleado_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_empleado_id_seq', 3, true);


--
-- Data for Name: empresa_empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_empresa (id, codigo, razons, ident, telefono, ciudad, activo, logo, email, direccion, calculos_id, configuracion_id) FROM stdin;
\.
COPY empresa_empresa (id, codigo, razons, ident, telefono, ciudad, activo, logo, email, direccion, calculos_id, configuracion_id) FROM '$$PATH$$/2900.dat';

--
-- Name: empresa_empresa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_empresa_id_seq', 1, true);


--
-- Data for Name: empresa_horasextra; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_horasextra (id, fecha, periodo, semestre, horas, tipo, dominical, contrato_id, empleado_id) FROM stdin;
\.
COPY empresa_horasextra (id, fecha, periodo, semestre, horas, tipo, dominical, contrato_id, empleado_id) FROM '$$PATH$$/2902.dat';

--
-- Name: empresa_horasextra_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_horasextra_id_seq', 1, false);


--
-- Data for Name: empresa_jefes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_jefes (id, departamento_id, empleado_id) FROM stdin;
\.
COPY empresa_jefes (id, departamento_id, empleado_id) FROM '$$PATH$$/2904.dat';

--
-- Name: empresa_jefes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_jefes_id_seq', 1, false);


--
-- Data for Name: empresa_liquidacionnomina; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_liquidacionnomina (id, periodo, semestre, fecha, fecha_corte, dias, cesa, intc, prim, hord, hexd, hexn, hxdd, hxnd, totl, contrato_id, empleado_id) FROM stdin;
\.
COPY empresa_liquidacionnomina (id, periodo, semestre, fecha, fecha_corte, dias, cesa, intc, prim, hord, hexd, hexn, hxdd, hxnd, totl, contrato_id, empleado_id) FROM '$$PATH$$/2906.dat';

--
-- Name: empresa_liquidacionnomina_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_liquidacionnomina_id_seq', 5, true);


--
-- Data for Name: empresa_requisito; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY empresa_requisito (id, educacion, formacion, habilidades, experiencia, cargo_id) FROM stdin;
\.
COPY empresa_requisito (id, educacion, formacion, habilidades, experiencia, cargo_id) FROM '$$PATH$$/2908.dat';

--
-- Name: empresa_requisito_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('empresa_requisito_id_seq', 1, false);


--
-- Data for Name: epc_actividad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_actividad (id, nombre, completado, fecha_completado, orden_id, dias_estimados, poscicion, formato_id, registro_id) FROM stdin;
\.
COPY epc_actividad (id, nombre, completado, fecha_completado, orden_id, dias_estimados, poscicion, formato_id, registro_id) FROM '$$PATH$$/2910.dat';

--
-- Name: epc_actividad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_actividad_id_seq', 51, true);


--
-- Data for Name: epc_adquisiscionmaterial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_adquisiscionmaterial (id, precio, material_id, orden_id, tipo_id) FROM stdin;
\.
COPY epc_adquisiscionmaterial (id, precio, material_id, orden_id, tipo_id) FROM '$$PATH$$/2912.dat';

--
-- Name: epc_adquisiscionmaterial_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_adquisiscionmaterial_id_seq', 2, true);


--
-- Name: epc_contratista_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_contratista_id_seq', 6, true);


--
-- Data for Name: epc_gantt; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_gantt (id, proyecto_id) FROM stdin;
\.
COPY epc_gantt (id, proyecto_id) FROM '$$PATH$$/2916.dat';

--
-- Name: epc_gantt_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_gantt_id_seq', 3, true);


--
-- Data for Name: epc_grupo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_grupo (id, nombre) FROM stdin;
\.
COPY epc_grupo (id, nombre) FROM '$$PATH$$/2930.dat';

--
-- Name: epc_grupo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_grupo_id_seq', 15, true);


--
-- Data for Name: epc_invitacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_invitacion (id, grupo_id, personal_id) FROM stdin;
\.
COPY epc_invitacion (id, grupo_id, personal_id) FROM '$$PATH$$/2932.dat';

--
-- Name: epc_invitacion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_invitacion_id_seq', 1, false);


--
-- Data for Name: epc_material; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_material (id, nombre, uso_unico) FROM stdin;
\.
COPY epc_material (id, nombre, uso_unico) FROM '$$PATH$$/2918.dat';

--
-- Name: epc_material_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_material_id_seq', 1, true);


--
-- Data for Name: epc_ordentrabajo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_ordentrabajo (id, nombre_corto, fecha, fecha_creacion, personal_id, proyecto_id, revisor_id) FROM stdin;
\.
COPY epc_ordentrabajo (id, nombre_corto, fecha, fecha_creacion, personal_id, proyecto_id, revisor_id) FROM '$$PATH$$/2920.dat';

--
-- Data for Name: epc_ordentrabajo_dependencias; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_ordentrabajo_dependencias (id, from_ordentrabajo_id, to_ordentrabajo_id) FROM stdin;
\.
COPY epc_ordentrabajo_dependencias (id, from_ordentrabajo_id, to_ordentrabajo_id) FROM '$$PATH$$/2922.dat';

--
-- Name: epc_ordentrabajo_dependencias_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_ordentrabajo_dependencias_id_seq', 14, true);


--
-- Name: epc_ordentrabajo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_ordentrabajo_id_seq', 46, true);


--
-- Data for Name: epc_personal; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_personal (id, nombre, empleado_id) FROM stdin;
\.
COPY epc_personal (id, nombre, empleado_id) FROM '$$PATH$$/2914.dat';

--
-- Data for Name: epc_progresografico; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_progresografico (id, orden_id) FROM stdin;
\.
COPY epc_progresografico (id, orden_id) FROM '$$PATH$$/2924.dat';

--
-- Name: epc_progresografico_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_progresografico_id_seq', 9, true);


--
-- Data for Name: epc_proyecto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_proyecto (id, nombre, grupo_id) FROM stdin;
\.
COPY epc_proyecto (id, nombre, grupo_id) FROM '$$PATH$$/2926.dat';

--
-- Name: epc_proyecto_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_proyecto_id_seq', 3, true);


--
-- Data for Name: epc_tipoadquisiscion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY epc_tipoadquisiscion (id, nombre) FROM stdin;
\.
COPY epc_tipoadquisiscion (id, nombre) FROM '$$PATH$$/2928.dat';

--
-- Name: epc_tipoadquisiscion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('epc_tipoadquisiscion_id_seq', 1, true);


--
-- Data for Name: formulario_campo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formulario_campo (id, nombre, tipo_id, grupo_id, ver_como) FROM stdin;
\.
COPY formulario_campo (id, nombre, tipo_id, grupo_id, ver_como) FROM '$$PATH$$/2940.dat';

--
-- Name: formulario_campo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formulario_campo_id_seq', 18, true);


--
-- Data for Name: formulario_entrada; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formulario_entrada (id, campo_id, registro_id, valor_id) FROM stdin;
\.
COPY formulario_entrada (id, campo_id, registro_id, valor_id) FROM '$$PATH$$/2942.dat';

--
-- Name: formulario_entrada_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formulario_entrada_id_seq', 19, true);


--
-- Data for Name: formulario_formulario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formulario_formulario (id, nombre, fecha) FROM stdin;
\.
COPY formulario_formulario (id, nombre, fecha) FROM '$$PATH$$/2944.dat';

--
-- Name: formulario_formulario_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formulario_formulario_id_seq', 2, true);


--
-- Data for Name: formulario_grupo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formulario_grupo (id, nombre, formulario_id) FROM stdin;
\.
COPY formulario_grupo (id, nombre, formulario_id) FROM '$$PATH$$/2981.dat';

--
-- Name: formulario_grupo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formulario_grupo_id_seq', 3, true);


--
-- Data for Name: formulario_registro; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formulario_registro (id, completado, fecha, empleado_id, formulario_id, revisor_id, correccion_de_id) FROM stdin;
\.
COPY formulario_registro (id, completado, fecha, empleado_id, formulario_id, revisor_id, correccion_de_id) FROM '$$PATH$$/2946.dat';

--
-- Name: formulario_registro_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formulario_registro_id_seq', 6, true);


--
-- Data for Name: formulario_revision; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formulario_revision (id, fecha, revision, comentario, registro_id) FROM stdin;
\.
COPY formulario_revision (id, fecha, revision, comentario, registro_id) FROM '$$PATH$$/2979.dat';

--
-- Name: formulario_revision_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formulario_revision_id_seq', 1, false);


--
-- Data for Name: formulario_tipo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formulario_tipo (id, forma, nombre, regular) FROM stdin;
\.
COPY formulario_tipo (id, forma, nombre, regular) FROM '$$PATH$$/2948.dat';

--
-- Name: formulario_tipo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formulario_tipo_id_seq', 2, true);


--
-- Data for Name: formulario_valor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY formulario_valor (id, valor, tipo_id) FROM stdin;
\.
COPY formulario_valor (id, valor, tipo_id) FROM '$$PATH$$/2950.dat';

--
-- Name: formulario_valor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('formulario_valor_id_seq', 19, true);


--
-- Data for Name: norma_formato; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY norma_formato (id, nombre, descripcion, documento, ejemplo, formulario_digital_id, item_id) FROM stdin;
\.
COPY norma_formato (id, nombre, descripcion, documento, ejemplo, formulario_digital_id, item_id) FROM '$$PATH$$/2952.dat';

--
-- Name: norma_formato_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('norma_formato_id_seq', 1, true);


--
-- Data for Name: norma_item; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY norma_item (id, nombre, descripcion, norma_id) FROM stdin;
\.
COPY norma_item (id, nombre, descripcion, norma_id) FROM '$$PATH$$/2954.dat';

--
-- Name: norma_item_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('norma_item_id_seq', 1, true);


--
-- Data for Name: norma_norma; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY norma_norma (id, nombre, edicion, fecha_edicion, referencia, activo) FROM stdin;
\.
COPY norma_norma (id, nombre, edicion, fecha_edicion, referencia, activo) FROM '$$PATH$$/2956.dat';

--
-- Name: norma_norma_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('norma_norma_id_seq', 1, true);


--
-- Data for Name: riesgo_cargoriesgo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY riesgo_cargoriesgo (id, acceso, impacto, contacto_aproteger, manejo_programas, incidencia_medidas, ponderacion, calificacion, cargo_id, criticidad_id) FROM stdin;
\.
COPY riesgo_cargoriesgo (id, acceso, impacto, contacto_aproteger, manejo_programas, incidencia_medidas, ponderacion, calificacion, cargo_id, criticidad_id) FROM '$$PATH$$/2958.dat';

--
-- Data for Name: riesgo_cargoriesgo_aproteger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY riesgo_cargoriesgo_aproteger (id, cargoriesgo_id, elementoproteger_id) FROM stdin;
\.
COPY riesgo_cargoriesgo_aproteger (id, cargoriesgo_id, elementoproteger_id) FROM '$$PATH$$/2972.dat';

--
-- Name: riesgo_cargoriesgo_aproteger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('riesgo_cargoriesgo_aproteger_id_seq', 1, false);


--
-- Name: riesgo_cargoriesgo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('riesgo_cargoriesgo_id_seq', 1, false);


--
-- Data for Name: riesgo_criticidad; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY riesgo_criticidad (id, nombre, descripcion) FROM stdin;
\.
COPY riesgo_criticidad (id, nombre, descripcion) FROM '$$PATH$$/2960.dat';

--
-- Name: riesgo_criticidad_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('riesgo_criticidad_id_seq', 1, false);


--
-- Data for Name: riesgo_elementoproteger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY riesgo_elementoproteger (id, nombre, descripcion) FROM stdin;
\.
COPY riesgo_elementoproteger (id, nombre, descripcion) FROM '$$PATH$$/2962.dat';

--
-- Name: riesgo_elementoproteger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('riesgo_elementoproteger_id_seq', 1, false);


--
-- Data for Name: riesgo_evaluacionempresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY riesgo_evaluacionempresa (id, fecha, aprobado, empresa_id) FROM stdin;
\.
COPY riesgo_evaluacionempresa (id, fecha, aprobado, empresa_id) FROM '$$PATH$$/2964.dat';

--
-- Name: riesgo_evaluacionempresa_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('riesgo_evaluacionempresa_id_seq', 1, true);


--
-- Data for Name: riesgo_evaluacionriesgos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY riesgo_evaluacionriesgos (id, fuente, medio, persona, metodo, probabilidad, consecuencia, controles_administrativos, controles_operacionales, "controles_talentoHumano", controles_instalacion, empresa_id, riesgo_id) FROM stdin;
\.
COPY riesgo_evaluacionriesgos (id, fuente, medio, persona, metodo, probabilidad, consecuencia, controles_administrativos, controles_operacionales, "controles_talentoHumano", controles_instalacion, empresa_id, riesgo_id) FROM '$$PATH$$/2966.dat';

--
-- Name: riesgo_evaluacionriesgos_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('riesgo_evaluacionriesgos_id_seq', 2, true);


--
-- Data for Name: riesgo_riesgo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY riesgo_riesgo (id, amenaza, riesgo, empresa_id) FROM stdin;
\.
COPY riesgo_riesgo (id, amenaza, riesgo, empresa_id) FROM '$$PATH$$/2968.dat';

--
-- Data for Name: riesgo_riesgo_aproteger; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY riesgo_riesgo_aproteger (id, riesgo_id, elementoproteger_id) FROM stdin;
\.
COPY riesgo_riesgo_aproteger (id, riesgo_id, elementoproteger_id) FROM '$$PATH$$/2970.dat';

--
-- Name: riesgo_riesgo_aproteger_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('riesgo_riesgo_aproteger_id_seq', 1, false);


--
-- Name: riesgo_riesgo_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('riesgo_riesgo_id_seq', 2, true);


--
-- Data for Name: usr_administrador; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usr_administrador (id, usuario_id) FROM stdin;
\.
COPY usr_administrador (id, usuario_id) FROM '$$PATH$$/2934.dat';

--
-- Name: usr_administrador_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('usr_administrador_id_seq', 1, false);


--
-- Data for Name: usr_auditor; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usr_auditor (id, usuario_id) FROM stdin;
\.
COPY usr_auditor (id, usuario_id) FROM '$$PATH$$/2936.dat';

--
-- Name: usr_auditor_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('usr_auditor_id_seq', 1, false);


--
-- Data for Name: usr_empleado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usr_empleado (user_ptr_id, _empleado_id) FROM stdin;
\.
COPY usr_empleado (user_ptr_id, _empleado_id) FROM '$$PATH$$/2937.dat';

--
-- Data for Name: usr_empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY usr_empresa (user_ptr_id, _empresa_id) FROM stdin;
\.
COPY usr_empresa (user_ptr_id, _empresa_id) FROM '$$PATH$$/2938.dat';

--
-- Data for Name: validable_template; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY validable_template (id, template, validable_id) FROM stdin;
\.
COPY validable_template (id, template, validable_id) FROM '$$PATH$$/2975.dat';

--
-- Name: validable_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('validable_template_id_seq', 1, false);


--
-- Data for Name: validable_validable; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY validable_validable (id, activo, identificador, class_name) FROM stdin;
\.
COPY validable_validable (id, activo, identificador, class_name) FROM '$$PATH$$/2977.dat';

--
-- Name: validable_validable_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('validable_validable_id_seq', 1, false);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: empresa_anio_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_anio
    ADD CONSTRAINT empresa_anio_pkey PRIMARY KEY (id);


--
-- Name: empresa_asistencia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_asistencia
    ADD CONSTRAINT empresa_asistencia_pkey PRIMARY KEY (id);


--
-- Name: empresa_calculos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_calculos
    ADD CONSTRAINT empresa_calculos_pkey PRIMARY KEY (id);


--
-- Name: empresa_cargo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_cargo
    ADD CONSTRAINT empresa_cargo_pkey PRIMARY KEY (id);


--
-- Name: empresa_configuracion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_configuracion
    ADD CONSTRAINT empresa_configuracion_pkey PRIMARY KEY (id);


--
-- Name: empresa_contrato_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_contrato
    ADD CONSTRAINT empresa_contrato_pkey PRIMARY KEY (id);


--
-- Name: empresa_departamento_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_departamento
    ADD CONSTRAINT empresa_departamento_pkey PRIMARY KEY (id);


--
-- Name: empresa_empleado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_empleado
    ADD CONSTRAINT empresa_empleado_pkey PRIMARY KEY (id);


--
-- Name: empresa_empresa_configuracion_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_empresa
    ADD CONSTRAINT empresa_empresa_configuracion_id_key UNIQUE (configuracion_id);


--
-- Name: empresa_empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_empresa
    ADD CONSTRAINT empresa_empresa_pkey PRIMARY KEY (id);


--
-- Name: empresa_horasextra_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_horasextra
    ADD CONSTRAINT empresa_horasextra_pkey PRIMARY KEY (id);


--
-- Name: empresa_jefes_departamento_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_jefes
    ADD CONSTRAINT empresa_jefes_departamento_id_key UNIQUE (departamento_id);


--
-- Name: empresa_jefes_empleado_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_jefes
    ADD CONSTRAINT empresa_jefes_empleado_id_key UNIQUE (empleado_id);


--
-- Name: empresa_jefes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_jefes
    ADD CONSTRAINT empresa_jefes_pkey PRIMARY KEY (id);


--
-- Name: empresa_liquidacionnomina_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_liquidacionnomina
    ADD CONSTRAINT empresa_liquidacionnomina_pkey PRIMARY KEY (id);


--
-- Name: empresa_requisito_cargo_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_requisito
    ADD CONSTRAINT empresa_requisito_cargo_id_key UNIQUE (cargo_id);


--
-- Name: empresa_requisito_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_requisito
    ADD CONSTRAINT empresa_requisito_pkey PRIMARY KEY (id);


--
-- Name: epc_actividad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_actividad
    ADD CONSTRAINT epc_actividad_pkey PRIMARY KEY (id);


--
-- Name: epc_adquisiscionmaterial_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_adquisiscionmaterial
    ADD CONSTRAINT epc_adquisiscionmaterial_pkey PRIMARY KEY (id);


--
-- Name: epc_contratista_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_personal
    ADD CONSTRAINT epc_contratista_pkey PRIMARY KEY (id);


--
-- Name: epc_gantt_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_gantt
    ADD CONSTRAINT epc_gantt_pkey PRIMARY KEY (id);


--
-- Name: epc_gantt_proyecto_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_gantt
    ADD CONSTRAINT epc_gantt_proyecto_id_key UNIQUE (proyecto_id);


--
-- Name: epc_grupo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_grupo
    ADD CONSTRAINT epc_grupo_pkey PRIMARY KEY (id);


--
-- Name: epc_invitacion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_invitacion
    ADD CONSTRAINT epc_invitacion_pkey PRIMARY KEY (id);


--
-- Name: epc_material_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_material
    ADD CONSTRAINT epc_material_pkey PRIMARY KEY (id);


--
-- Name: epc_ordentrabajo_dependencia_from_ordentrabajo_id_c5144205_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_ordentrabajo_dependencias
    ADD CONSTRAINT epc_ordentrabajo_dependencia_from_ordentrabajo_id_c5144205_uniq UNIQUE (from_ordentrabajo_id, to_ordentrabajo_id);


--
-- Name: epc_ordentrabajo_dependencias_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_ordentrabajo_dependencias
    ADD CONSTRAINT epc_ordentrabajo_dependencias_pkey PRIMARY KEY (id);


--
-- Name: epc_ordentrabajo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_ordentrabajo
    ADD CONSTRAINT epc_ordentrabajo_pkey PRIMARY KEY (id);


--
-- Name: epc_progresografico_orden_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_progresografico
    ADD CONSTRAINT epc_progresografico_orden_id_key UNIQUE (orden_id);


--
-- Name: epc_progresografico_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_progresografico
    ADD CONSTRAINT epc_progresografico_pkey PRIMARY KEY (id);


--
-- Name: epc_proyecto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_proyecto
    ADD CONSTRAINT epc_proyecto_pkey PRIMARY KEY (id);


--
-- Name: epc_tipoadquisiscion_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_tipoadquisiscion
    ADD CONSTRAINT epc_tipoadquisiscion_pkey PRIMARY KEY (id);


--
-- Name: formulario_campo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_campo
    ADD CONSTRAINT formulario_campo_pkey PRIMARY KEY (id);


--
-- Name: formulario_entrada_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_entrada
    ADD CONSTRAINT formulario_entrada_pkey PRIMARY KEY (id);


--
-- Name: formulario_formulario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_formulario
    ADD CONSTRAINT formulario_formulario_pkey PRIMARY KEY (id);


--
-- Name: formulario_grupo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_grupo
    ADD CONSTRAINT formulario_grupo_pkey PRIMARY KEY (id);


--
-- Name: formulario_registro_correccion_de_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_registro
    ADD CONSTRAINT formulario_registro_correccion_de_id_key UNIQUE (correccion_de_id);


--
-- Name: formulario_registro_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_registro
    ADD CONSTRAINT formulario_registro_pkey PRIMARY KEY (id);


--
-- Name: formulario_revision_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_revision
    ADD CONSTRAINT formulario_revision_pkey PRIMARY KEY (id);


--
-- Name: formulario_revision_registro_id_0883997d_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_revision
    ADD CONSTRAINT formulario_revision_registro_id_0883997d_uniq UNIQUE (registro_id);


--
-- Name: formulario_tipo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_tipo
    ADD CONSTRAINT formulario_tipo_pkey PRIMARY KEY (id);


--
-- Name: formulario_valor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_valor
    ADD CONSTRAINT formulario_valor_pkey PRIMARY KEY (id);


--
-- Name: norma_formato_formulario_digital_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY norma_formato
    ADD CONSTRAINT norma_formato_formulario_digital_id_key UNIQUE (formulario_digital_id);


--
-- Name: norma_formato_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY norma_formato
    ADD CONSTRAINT norma_formato_pkey PRIMARY KEY (id);


--
-- Name: norma_item_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY norma_item
    ADD CONSTRAINT norma_item_pkey PRIMARY KEY (id);


--
-- Name: norma_norma_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY norma_norma
    ADD CONSTRAINT norma_norma_pkey PRIMARY KEY (id);


--
-- Name: riesgo_cargoriesgo_aproteger_cargoriesgo_id_3a08f318_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_cargoriesgo_aproteger
    ADD CONSTRAINT riesgo_cargoriesgo_aproteger_cargoriesgo_id_3a08f318_uniq UNIQUE (cargoriesgo_id, elementoproteger_id);


--
-- Name: riesgo_cargoriesgo_aproteger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_cargoriesgo_aproteger
    ADD CONSTRAINT riesgo_cargoriesgo_aproteger_pkey PRIMARY KEY (id);


--
-- Name: riesgo_cargoriesgo_cargo_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_cargoriesgo
    ADD CONSTRAINT riesgo_cargoriesgo_cargo_id_key UNIQUE (cargo_id);


--
-- Name: riesgo_cargoriesgo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_cargoriesgo
    ADD CONSTRAINT riesgo_cargoriesgo_pkey PRIMARY KEY (id);


--
-- Name: riesgo_criticidad_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_criticidad
    ADD CONSTRAINT riesgo_criticidad_pkey PRIMARY KEY (id);


--
-- Name: riesgo_elementoproteger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_elementoproteger
    ADD CONSTRAINT riesgo_elementoproteger_pkey PRIMARY KEY (id);


--
-- Name: riesgo_evaluacionempresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_evaluacionempresa
    ADD CONSTRAINT riesgo_evaluacionempresa_pkey PRIMARY KEY (id);


--
-- Name: riesgo_evaluacionriesgos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_evaluacionriesgos
    ADD CONSTRAINT riesgo_evaluacionriesgos_pkey PRIMARY KEY (id);


--
-- Name: riesgo_riesgo_aproteger_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_riesgo_aproteger
    ADD CONSTRAINT riesgo_riesgo_aproteger_pkey PRIMARY KEY (id);


--
-- Name: riesgo_riesgo_aproteger_riesgo_id_1aaca1e0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_riesgo_aproteger
    ADD CONSTRAINT riesgo_riesgo_aproteger_riesgo_id_1aaca1e0_uniq UNIQUE (riesgo_id, elementoproteger_id);


--
-- Name: riesgo_riesgo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_riesgo
    ADD CONSTRAINT riesgo_riesgo_pkey PRIMARY KEY (id);


--
-- Name: usr_administrador_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_administrador
    ADD CONSTRAINT usr_administrador_pkey PRIMARY KEY (id);


--
-- Name: usr_administrador_usuario_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_administrador
    ADD CONSTRAINT usr_administrador_usuario_id_key UNIQUE (usuario_id);


--
-- Name: usr_auditor_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_auditor
    ADD CONSTRAINT usr_auditor_pkey PRIMARY KEY (id);


--
-- Name: usr_auditor_usuario_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_auditor
    ADD CONSTRAINT usr_auditor_usuario_id_key UNIQUE (usuario_id);


--
-- Name: usr_empleado__empleado_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_empleado
    ADD CONSTRAINT usr_empleado__empleado_id_key UNIQUE (_empleado_id);


--
-- Name: usr_empleado_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_empleado
    ADD CONSTRAINT usr_empleado_pkey PRIMARY KEY (user_ptr_id);


--
-- Name: usr_empresa_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_empresa
    ADD CONSTRAINT usr_empresa_pkey PRIMARY KEY (user_ptr_id);


--
-- Name: validable_template_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validable_template
    ADD CONSTRAINT validable_template_pkey PRIMARY KEY (id);


--
-- Name: validable_template_validable_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validable_template
    ADD CONSTRAINT validable_template_validable_id_key UNIQUE (validable_id);


--
-- Name: validable_validable_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validable_validable
    ADD CONSTRAINT validable_validable_pkey PRIMARY KEY (id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_name_a6ea08ec_like ON auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_0e939a4f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_0e939a4f ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_8373b171; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_group_permissions_8373b171 ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_permission_417f1b1c ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_0e939a4f; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_0e939a4f ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_groups_e8701ad4 ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_8373b171; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_8373b171 ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_user_permissions_e8701ad4 ON auth_user_user_permissions USING btree (user_id);


--
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX auth_user_username_6821ab7c_like ON auth_user USING btree (username varchar_pattern_ops);


--
-- Name: django_admin_log_417f1b1c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_417f1b1c ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_e8701ad4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_admin_log_e8701ad4 ON django_admin_log USING btree (user_id);


--
-- Name: django_session_de54fa62; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_de54fa62 ON django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX django_session_session_key_c0390e0f_like ON django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: empresa_asistencia_473dea9e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_asistencia_473dea9e ON empresa_asistencia USING btree (empleado_id);


--
-- Name: empresa_asistencia_868819a8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_asistencia_868819a8 ON empresa_asistencia USING btree (contrato_id);


--
-- Name: empresa_cargo_f5acfb16; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_cargo_f5acfb16 ON empresa_cargo USING btree (departamento_id);


--
-- Name: empresa_contrato_473dea9e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_contrato_473dea9e ON empresa_contrato USING btree (empleado_id);


--
-- Name: empresa_contrato_d036ebc9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_contrato_d036ebc9 ON empresa_contrato USING btree (cargo_id);


--
-- Name: empresa_departamento_bff560e2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_departamento_bff560e2 ON empresa_departamento USING btree (superior_id);


--
-- Name: empresa_departamento_e8f8b1ef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_departamento_e8f8b1ef ON empresa_departamento USING btree (empresa_id);


--
-- Name: empresa_empleado_d036ebc9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_empleado_d036ebc9 ON empresa_empleado USING btree (cargo_id);


--
-- Name: empresa_empleado_e8f8b1ef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_empleado_e8f8b1ef ON empresa_empleado USING btree (empresa_id);


--
-- Name: empresa_empresa_59c4a75e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_empresa_59c4a75e ON empresa_empresa USING btree (calculos_id);


--
-- Name: empresa_horasextra_473dea9e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_horasextra_473dea9e ON empresa_horasextra USING btree (empleado_id);


--
-- Name: empresa_horasextra_868819a8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_horasextra_868819a8 ON empresa_horasextra USING btree (contrato_id);


--
-- Name: empresa_liquidacionnomina_473dea9e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_liquidacionnomina_473dea9e ON empresa_liquidacionnomina USING btree (empleado_id);


--
-- Name: empresa_liquidacionnomina_868819a8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX empresa_liquidacionnomina_868819a8 ON empresa_liquidacionnomina USING btree (contrato_id);


--
-- Name: epc_actividad_69162670; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_actividad_69162670 ON epc_actividad USING btree (registro_id);


--
-- Name: epc_actividad_7fa7f4f4; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_actividad_7fa7f4f4 ON epc_actividad USING btree (formato_id);


--
-- Name: epc_actividad_c33caba2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_actividad_c33caba2 ON epc_actividad USING btree (orden_id);


--
-- Name: epc_actividad_poscicion_5721017e_uniq; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_actividad_poscicion_5721017e_uniq ON epc_actividad USING btree (poscicion);


--
-- Name: epc_adquisiscionmaterial_c33caba2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_adquisiscionmaterial_c33caba2 ON epc_adquisiscionmaterial USING btree (orden_id);


--
-- Name: epc_adquisiscionmaterial_d3c0c18a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_adquisiscionmaterial_d3c0c18a ON epc_adquisiscionmaterial USING btree (tipo_id);


--
-- Name: epc_adquisiscionmaterial_eb4b9aaa; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_adquisiscionmaterial_eb4b9aaa ON epc_adquisiscionmaterial USING btree (material_id);


--
-- Name: epc_invitacion_4df638e8; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_invitacion_4df638e8 ON epc_invitacion USING btree (personal_id);


--
-- Name: epc_invitacion_acaeb2d6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_invitacion_acaeb2d6 ON epc_invitacion USING btree (grupo_id);


--
-- Name: epc_ordentrabajo_7485a580; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_ordentrabajo_7485a580 ON epc_ordentrabajo USING btree (revisor_id);


--
-- Name: epc_ordentrabajo_beaf1098; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_ordentrabajo_beaf1098 ON epc_ordentrabajo USING btree (personal_id);


--
-- Name: epc_ordentrabajo_dependencias_559a1641; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_ordentrabajo_dependencias_559a1641 ON epc_ordentrabajo_dependencias USING btree (to_ordentrabajo_id);


--
-- Name: epc_ordentrabajo_dependencias_70fefa6c; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_ordentrabajo_dependencias_70fefa6c ON epc_ordentrabajo_dependencias USING btree (from_ordentrabajo_id);


--
-- Name: epc_ordentrabajo_f543c3f9; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_ordentrabajo_f543c3f9 ON epc_ordentrabajo USING btree (proyecto_id);


--
-- Name: epc_personal_473dea9e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_personal_473dea9e ON epc_personal USING btree (empleado_id);


--
-- Name: epc_proyecto_acaeb2d6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX epc_proyecto_acaeb2d6 ON epc_proyecto USING btree (grupo_id);


--
-- Name: formulario_campo_acaeb2d6; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_campo_acaeb2d6 ON formulario_campo USING btree (grupo_id);


--
-- Name: formulario_campo_d3c0c18a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_campo_d3c0c18a ON formulario_campo USING btree (tipo_id);


--
-- Name: formulario_entrada_0cdaf9cd; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_entrada_0cdaf9cd ON formulario_entrada USING btree (valor_id);


--
-- Name: formulario_entrada_69162670; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_entrada_69162670 ON formulario_entrada USING btree (registro_id);


--
-- Name: formulario_entrada_e40f192a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_entrada_e40f192a ON formulario_entrada USING btree (campo_id);


--
-- Name: formulario_grupo_3fe51010; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_grupo_3fe51010 ON formulario_grupo USING btree (formulario_id);


--
-- Name: formulario_registro_3fe51010; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_registro_3fe51010 ON formulario_registro USING btree (formulario_id);


--
-- Name: formulario_registro_473dea9e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_registro_473dea9e ON formulario_registro USING btree (empleado_id);


--
-- Name: formulario_registro_7485a580; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_registro_7485a580 ON formulario_registro USING btree (revisor_id);


--
-- Name: formulario_revision_69162670; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_revision_69162670 ON formulario_revision USING btree (registro_id);


--
-- Name: formulario_valor_d3c0c18a; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX formulario_valor_d3c0c18a ON formulario_valor USING btree (tipo_id);


--
-- Name: norma_formato_82bfda79; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX norma_formato_82bfda79 ON norma_formato USING btree (item_id);


--
-- Name: norma_item_85441dd2; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX norma_item_85441dd2 ON norma_item USING btree (norma_id);


--
-- Name: riesgo_cargoriesgo_9c895cae; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX riesgo_cargoriesgo_9c895cae ON riesgo_cargoriesgo USING btree (criticidad_id);


--
-- Name: riesgo_cargoriesgo_aproteger_38b7f5b7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX riesgo_cargoriesgo_aproteger_38b7f5b7 ON riesgo_cargoriesgo_aproteger USING btree (elementoproteger_id);


--
-- Name: riesgo_cargoriesgo_aproteger_e62b7a7b; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX riesgo_cargoriesgo_aproteger_e62b7a7b ON riesgo_cargoriesgo_aproteger USING btree (cargoriesgo_id);


--
-- Name: riesgo_evaluacionempresa_e8f8b1ef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX riesgo_evaluacionempresa_e8f8b1ef ON riesgo_evaluacionempresa USING btree (empresa_id);


--
-- Name: riesgo_evaluacionriesgos_5c82ee88; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX riesgo_evaluacionriesgos_5c82ee88 ON riesgo_evaluacionriesgos USING btree (riesgo_id);


--
-- Name: riesgo_evaluacionriesgos_e8f8b1ef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX riesgo_evaluacionriesgos_e8f8b1ef ON riesgo_evaluacionriesgos USING btree (empresa_id);


--
-- Name: riesgo_riesgo_aproteger_38b7f5b7; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX riesgo_riesgo_aproteger_38b7f5b7 ON riesgo_riesgo_aproteger USING btree (elementoproteger_id);


--
-- Name: riesgo_riesgo_aproteger_5c82ee88; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX riesgo_riesgo_aproteger_5c82ee88 ON riesgo_riesgo_aproteger USING btree (riesgo_id);


--
-- Name: riesgo_riesgo_e8f8b1ef; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX riesgo_riesgo_e8f8b1ef ON riesgo_riesgo USING btree (empresa_id);


--
-- Name: usr_empresa_02cd0d7e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX usr_empresa_02cd0d7e ON usr_empresa USING btree (_empresa_id);


--
-- Name: auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permiss_permission_id_84c5c92e_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permiss_content_type_id_2f476e4b_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_per_permission_id_1fbb5f2c_fk_auth_permission_id FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_content_type_id_c4bce8eb_fk_django_content_type_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_content_type_id_c4bce8eb_fk_django_content_type_id FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_asistencia_contrato_id_93493407_fk_empresa_contrato_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_asistencia
    ADD CONSTRAINT empresa_asistencia_contrato_id_93493407_fk_empresa_contrato_id FOREIGN KEY (contrato_id) REFERENCES empresa_contrato(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_asistencia_empleado_id_7ef8bf26_fk_empresa_empleado_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_asistencia
    ADD CONSTRAINT empresa_asistencia_empleado_id_7ef8bf26_fk_empresa_empleado_id FOREIGN KEY (empleado_id) REFERENCES empresa_empleado(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_car_departamento_id_e9dec7b4_fk_empresa_departamento_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_cargo
    ADD CONSTRAINT empresa_car_departamento_id_e9dec7b4_fk_empresa_departamento_id FOREIGN KEY (departamento_id) REFERENCES empresa_departamento(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_contrato_cargo_id_f58ee511_fk_empresa_cargo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_contrato
    ADD CONSTRAINT empresa_contrato_cargo_id_f58ee511_fk_empresa_cargo_id FOREIGN KEY (cargo_id) REFERENCES empresa_cargo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_contrato_empleado_id_3ea030f1_fk_empresa_empleado_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_contrato
    ADD CONSTRAINT empresa_contrato_empleado_id_3ea030f1_fk_empresa_empleado_id FOREIGN KEY (empleado_id) REFERENCES empresa_empleado(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_departa_superior_id_5b87e15b_fk_empresa_departamento_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_departamento
    ADD CONSTRAINT empresa_departa_superior_id_5b87e15b_fk_empresa_departamento_id FOREIGN KEY (superior_id) REFERENCES empresa_departamento(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_departamento_empresa_id_ccfc7787_fk_empresa_empresa_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_departamento
    ADD CONSTRAINT empresa_departamento_empresa_id_ccfc7787_fk_empresa_empresa_id FOREIGN KEY (empresa_id) REFERENCES empresa_empresa(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_e_configuracion_id_c0005a8b_fk_empresa_configuracion_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_empresa
    ADD CONSTRAINT empresa_e_configuracion_id_c0005a8b_fk_empresa_configuracion_id FOREIGN KEY (configuracion_id) REFERENCES empresa_configuracion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_empleado_cargo_id_94fcd079_fk_empresa_cargo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_empleado
    ADD CONSTRAINT empresa_empleado_cargo_id_94fcd079_fk_empresa_cargo_id FOREIGN KEY (cargo_id) REFERENCES empresa_cargo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_empleado_empresa_id_1fd4c0fa_fk_empresa_empresa_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_empleado
    ADD CONSTRAINT empresa_empleado_empresa_id_1fd4c0fa_fk_empresa_empresa_id FOREIGN KEY (empresa_id) REFERENCES empresa_empresa(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_empresa_calculos_id_e73b5bbe_fk_empresa_calculos_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_empresa
    ADD CONSTRAINT empresa_empresa_calculos_id_e73b5bbe_fk_empresa_calculos_id FOREIGN KEY (calculos_id) REFERENCES empresa_calculos(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_horasextra_contrato_id_3bb560f4_fk_empresa_contrato_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_horasextra
    ADD CONSTRAINT empresa_horasextra_contrato_id_3bb560f4_fk_empresa_contrato_id FOREIGN KEY (contrato_id) REFERENCES empresa_contrato(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_horasextra_empleado_id_c9b697d1_fk_empresa_empleado_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_horasextra
    ADD CONSTRAINT empresa_horasextra_empleado_id_c9b697d1_fk_empresa_empleado_id FOREIGN KEY (empleado_id) REFERENCES empresa_empleado(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_jef_departamento_id_fcfffbe9_fk_empresa_departamento_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_jefes
    ADD CONSTRAINT empresa_jef_departamento_id_fcfffbe9_fk_empresa_departamento_id FOREIGN KEY (departamento_id) REFERENCES empresa_departamento(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_jefes_empleado_id_afa73faa_fk_empresa_empleado_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_jefes
    ADD CONSTRAINT empresa_jefes_empleado_id_afa73faa_fk_empresa_empleado_id FOREIGN KEY (empleado_id) REFERENCES empresa_empleado(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_liquidacion_contrato_id_fadf3c9d_fk_empresa_contrato_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_liquidacionnomina
    ADD CONSTRAINT empresa_liquidacion_contrato_id_fadf3c9d_fk_empresa_contrato_id FOREIGN KEY (contrato_id) REFERENCES empresa_contrato(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_liquidacion_empleado_id_16cecdb5_fk_empresa_empleado_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_liquidacionnomina
    ADD CONSTRAINT empresa_liquidacion_empleado_id_16cecdb5_fk_empresa_empleado_id FOREIGN KEY (empleado_id) REFERENCES empresa_empleado(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: empresa_requisito_cargo_id_cbf75797_fk_empresa_cargo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY empresa_requisito
    ADD CONSTRAINT empresa_requisito_cargo_id_cbf75797_fk_empresa_cargo_id FOREIGN KEY (cargo_id) REFERENCES empresa_cargo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_actividad_formato_id_93cbb784_fk_formulario_formulario_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_actividad
    ADD CONSTRAINT epc_actividad_formato_id_93cbb784_fk_formulario_formulario_id FOREIGN KEY (formato_id) REFERENCES formulario_formulario(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_actividad_orden_id_1e542c12_fk_epc_ordentrabajo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_actividad
    ADD CONSTRAINT epc_actividad_orden_id_1e542c12_fk_epc_ordentrabajo_id FOREIGN KEY (orden_id) REFERENCES epc_ordentrabajo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_actividad_registro_id_18505226_fk_formulario_registro_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_actividad
    ADD CONSTRAINT epc_actividad_registro_id_18505226_fk_formulario_registro_id FOREIGN KEY (registro_id) REFERENCES formulario_registro(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_adquisiscionmat_tipo_id_78abdd9f_fk_epc_tipoadquisiscion_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_adquisiscionmaterial
    ADD CONSTRAINT epc_adquisiscionmat_tipo_id_78abdd9f_fk_epc_tipoadquisiscion_id FOREIGN KEY (tipo_id) REFERENCES epc_tipoadquisiscion(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_adquisiscionmateri_orden_id_cc504209_fk_epc_ordentrabajo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_adquisiscionmaterial
    ADD CONSTRAINT epc_adquisiscionmateri_orden_id_cc504209_fk_epc_ordentrabajo_id FOREIGN KEY (orden_id) REFERENCES epc_ordentrabajo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_adquisiscionmateria_material_id_e5aa9744_fk_epc_material_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_adquisiscionmaterial
    ADD CONSTRAINT epc_adquisiscionmateria_material_id_e5aa9744_fk_epc_material_id FOREIGN KEY (material_id) REFERENCES epc_material(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_gantt_proyecto_id_5a532a4b_fk_epc_proyecto_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_gantt
    ADD CONSTRAINT epc_gantt_proyecto_id_5a532a4b_fk_epc_proyecto_id FOREIGN KEY (proyecto_id) REFERENCES epc_proyecto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_invitacion_grupo_id_2e12aff9_fk_epc_grupo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_invitacion
    ADD CONSTRAINT epc_invitacion_grupo_id_2e12aff9_fk_epc_grupo_id FOREIGN KEY (grupo_id) REFERENCES epc_grupo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_invitacion_personal_id_0831a878_fk_epc_personal_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_invitacion
    ADD CONSTRAINT epc_invitacion_personal_id_0831a878_fk_epc_personal_id FOREIGN KEY (personal_id) REFERENCES epc_personal(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_ordent_from_ordentrabajo_id_923b73a2_fk_epc_ordentrabajo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_ordentrabajo_dependencias
    ADD CONSTRAINT epc_ordent_from_ordentrabajo_id_923b73a2_fk_epc_ordentrabajo_id FOREIGN KEY (from_ordentrabajo_id) REFERENCES epc_ordentrabajo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_ordentra_to_ordentrabajo_id_4e0f5e5c_fk_epc_ordentrabajo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_ordentrabajo_dependencias
    ADD CONSTRAINT epc_ordentra_to_ordentrabajo_id_4e0f5e5c_fk_epc_ordentrabajo_id FOREIGN KEY (to_ordentrabajo_id) REFERENCES epc_ordentrabajo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_ordentrabajo_personal_id_70bf2ec5_fk_epc_personal_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_ordentrabajo
    ADD CONSTRAINT epc_ordentrabajo_personal_id_70bf2ec5_fk_epc_personal_id FOREIGN KEY (personal_id) REFERENCES epc_personal(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_ordentrabajo_proyecto_id_806c76a7_fk_epc_proyecto_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_ordentrabajo
    ADD CONSTRAINT epc_ordentrabajo_proyecto_id_806c76a7_fk_epc_proyecto_id FOREIGN KEY (proyecto_id) REFERENCES epc_proyecto(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_ordentrabajo_revisor_id_aa2d418b_fk_epc_personal_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_ordentrabajo
    ADD CONSTRAINT epc_ordentrabajo_revisor_id_aa2d418b_fk_epc_personal_id FOREIGN KEY (revisor_id) REFERENCES epc_personal(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_personal_empleado_id_44a99a67_fk_empresa_empleado_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_personal
    ADD CONSTRAINT epc_personal_empleado_id_44a99a67_fk_empresa_empleado_id FOREIGN KEY (empleado_id) REFERENCES empresa_empleado(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_progresografico_orden_id_0055a344_fk_epc_ordentrabajo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_progresografico
    ADD CONSTRAINT epc_progresografico_orden_id_0055a344_fk_epc_ordentrabajo_id FOREIGN KEY (orden_id) REFERENCES epc_ordentrabajo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: epc_proyecto_grupo_id_80910624_fk_epc_grupo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY epc_proyecto
    ADD CONSTRAINT epc_proyecto_grupo_id_80910624_fk_epc_grupo_id FOREIGN KEY (grupo_id) REFERENCES epc_grupo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario__correccion_de_id_348a1bea_fk_formulario_revision_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_registro
    ADD CONSTRAINT formulario__correccion_de_id_348a1bea_fk_formulario_revision_id FOREIGN KEY (correccion_de_id) REFERENCES formulario_revision(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_campo_grupo_id_a0974800_fk_formulario_grupo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_campo
    ADD CONSTRAINT formulario_campo_grupo_id_a0974800_fk_formulario_grupo_id FOREIGN KEY (grupo_id) REFERENCES formulario_grupo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_campo_tipo_id_7053693d_fk_formulario_tipo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_campo
    ADD CONSTRAINT formulario_campo_tipo_id_7053693d_fk_formulario_tipo_id FOREIGN KEY (tipo_id) REFERENCES formulario_tipo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_entra_registro_id_65067948_fk_formulario_registro_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_entrada
    ADD CONSTRAINT formulario_entra_registro_id_65067948_fk_formulario_registro_id FOREIGN KEY (registro_id) REFERENCES formulario_registro(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_entrada_campo_id_b6ca9d9a_fk_formulario_campo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_entrada
    ADD CONSTRAINT formulario_entrada_campo_id_b6ca9d9a_fk_formulario_campo_id FOREIGN KEY (campo_id) REFERENCES formulario_campo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_entrada_valor_id_49a642ff_fk_formulario_valor_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_entrada
    ADD CONSTRAINT formulario_entrada_valor_id_49a642ff_fk_formulario_valor_id FOREIGN KEY (valor_id) REFERENCES formulario_valor(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_g_formulario_id_c633a729_fk_formulario_formulario_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_grupo
    ADD CONSTRAINT formulario_g_formulario_id_c633a729_fk_formulario_formulario_id FOREIGN KEY (formulario_id) REFERENCES formulario_formulario(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_r_formulario_id_a70ee9cc_fk_formulario_formulario_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_registro
    ADD CONSTRAINT formulario_r_formulario_id_a70ee9cc_fk_formulario_formulario_id FOREIGN KEY (formulario_id) REFERENCES formulario_formulario(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_reg_empleado_id_43cb4772_fk_usr_empleado_user_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_registro
    ADD CONSTRAINT formulario_reg_empleado_id_43cb4772_fk_usr_empleado_user_ptr_id FOREIGN KEY (empleado_id) REFERENCES usr_empleado(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_regi_revisor_id_97ee2c76_fk_usr_empleado_user_ptr_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_registro
    ADD CONSTRAINT formulario_regi_revisor_id_97ee2c76_fk_usr_empleado_user_ptr_id FOREIGN KEY (revisor_id) REFERENCES usr_empleado(user_ptr_id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_revis_registro_id_0883997d_fk_formulario_registro_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_revision
    ADD CONSTRAINT formulario_revis_registro_id_0883997d_fk_formulario_registro_id FOREIGN KEY (registro_id) REFERENCES formulario_registro(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: formulario_valor_tipo_id_a2eccb49_fk_formulario_tipo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY formulario_valor
    ADD CONSTRAINT formulario_valor_tipo_id_a2eccb49_fk_formulario_tipo_id FOREIGN KEY (tipo_id) REFERENCES formulario_tipo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: norm_formulario_digital_id_be65fd93_fk_formulario_formulario_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY norma_formato
    ADD CONSTRAINT norm_formulario_digital_id_be65fd93_fk_formulario_formulario_id FOREIGN KEY (formulario_digital_id) REFERENCES formulario_formulario(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: norma_formato_item_id_6f3d34c4_fk_norma_item_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY norma_formato
    ADD CONSTRAINT norma_formato_item_id_6f3d34c4_fk_norma_item_id FOREIGN KEY (item_id) REFERENCES norma_item(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: norma_item_norma_id_ed183017_fk_norma_norma_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY norma_item
    ADD CONSTRAINT norma_item_norma_id_ed183017_fk_norma_norma_id FOREIGN KEY (norma_id) REFERENCES norma_norma(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ries_elementoproteger_id_bf4062e6_fk_riesgo_elementoproteger_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_riesgo_aproteger
    ADD CONSTRAINT ries_elementoproteger_id_bf4062e6_fk_riesgo_elementoproteger_id FOREIGN KEY (elementoproteger_id) REFERENCES riesgo_elementoproteger(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: ries_elementoproteger_id_f8488bf1_fk_riesgo_elementoproteger_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_cargoriesgo_aproteger
    ADD CONSTRAINT ries_elementoproteger_id_f8488bf1_fk_riesgo_elementoproteger_id FOREIGN KEY (elementoproteger_id) REFERENCES riesgo_elementoproteger(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: riesgo_cargori_cargoriesgo_id_2dc85ba9_fk_riesgo_cargoriesgo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_cargoriesgo_aproteger
    ADD CONSTRAINT riesgo_cargori_cargoriesgo_id_2dc85ba9_fk_riesgo_cargoriesgo_id FOREIGN KEY (cargoriesgo_id) REFERENCES riesgo_cargoriesgo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: riesgo_cargories_criticidad_id_413d8e17_fk_riesgo_criticidad_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_cargoriesgo
    ADD CONSTRAINT riesgo_cargories_criticidad_id_413d8e17_fk_riesgo_criticidad_id FOREIGN KEY (criticidad_id) REFERENCES riesgo_criticidad(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: riesgo_cargoriesgo_cargo_id_6435fda8_fk_empresa_cargo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_cargoriesgo
    ADD CONSTRAINT riesgo_cargoriesgo_cargo_id_6435fda8_fk_empresa_cargo_id FOREIGN KEY (cargo_id) REFERENCES empresa_cargo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: riesgo_evalu_empresa_id_2f2d1fb6_fk_riesgo_evaluacionempresa_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_evaluacionriesgos
    ADD CONSTRAINT riesgo_evalu_empresa_id_2f2d1fb6_fk_riesgo_evaluacionempresa_id FOREIGN KEY (empresa_id) REFERENCES riesgo_evaluacionempresa(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: riesgo_evaluacionempr_empresa_id_b50621e2_fk_empresa_empresa_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_evaluacionempresa
    ADD CONSTRAINT riesgo_evaluacionempr_empresa_id_b50621e2_fk_empresa_empresa_id FOREIGN KEY (empresa_id) REFERENCES empresa_empresa(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: riesgo_evaluacionriesgos_riesgo_id_f60b4173_fk_riesgo_riesgo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_evaluacionriesgos
    ADD CONSTRAINT riesgo_evaluacionriesgos_riesgo_id_f60b4173_fk_riesgo_riesgo_id FOREIGN KEY (riesgo_id) REFERENCES riesgo_riesgo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: riesgo_riesgo_aproteger_riesgo_id_5dd3585b_fk_riesgo_riesgo_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_riesgo_aproteger
    ADD CONSTRAINT riesgo_riesgo_aproteger_riesgo_id_5dd3585b_fk_riesgo_riesgo_id FOREIGN KEY (riesgo_id) REFERENCES riesgo_riesgo(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: riesgo_riesgo_empresa_id_5dffbcdf_fk_empresa_empresa_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY riesgo_riesgo
    ADD CONSTRAINT riesgo_riesgo_empresa_id_5dffbcdf_fk_empresa_empresa_id FOREIGN KEY (empresa_id) REFERENCES empresa_empresa(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: usr_administrador_usuario_id_78d32edb_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_administrador
    ADD CONSTRAINT usr_administrador_usuario_id_78d32edb_fk_auth_user_id FOREIGN KEY (usuario_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: usr_auditor_usuario_id_cc50615c_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_auditor
    ADD CONSTRAINT usr_auditor_usuario_id_cc50615c_fk_auth_user_id FOREIGN KEY (usuario_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: usr_empleado__empleado_id_64b11834_fk_empresa_empleado_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_empleado
    ADD CONSTRAINT usr_empleado__empleado_id_64b11834_fk_empresa_empleado_id FOREIGN KEY (_empleado_id) REFERENCES empresa_empleado(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: usr_empleado_user_ptr_id_1113d746_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_empleado
    ADD CONSTRAINT usr_empleado_user_ptr_id_1113d746_fk_auth_user_id FOREIGN KEY (user_ptr_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: usr_empresa__empresa_id_0a9c712d_fk_empresa_empresa_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_empresa
    ADD CONSTRAINT usr_empresa__empresa_id_0a9c712d_fk_empresa_empresa_id FOREIGN KEY (_empresa_id) REFERENCES empresa_empresa(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: usr_empresa_user_ptr_id_86799ee2_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY usr_empresa
    ADD CONSTRAINT usr_empresa_user_ptr_id_86799ee2_fk_auth_user_id FOREIGN KEY (user_ptr_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: validable_templ_validable_id_7207bde9_fk_validable_validable_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY validable_template
    ADD CONSTRAINT validable_templ_validable_id_7207bde9_fk_validable_validable_id FOREIGN KEY (validable_id) REFERENCES validable_validable(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

